# Bellum AI Event Bridge 0.3.4

Target: Bannerlord 1.4.5.115026 / Bellum Civile 1.2.7 / AI Influence 6.0.0.

## Change from 0.3.3

Removes the structured war-casualty feature after testing showed the AI treating whole-war totals as single-battle losses. The bridge no longer calls vanilla GetCasualties, supplies suffered/inflicted/combined totals, or computes/renders casualty changes over trend intervals. This applies to character prompts, global dynamic-event context and war-briefing diagnostics. An old `IncludeWarCasualties: true` setting is ignored; no settings reset is needed.

Existing 0.3.3 observations remain readable, including their legacy serialized fields. Their score/territory history is preserved; legacy casualty fields are never rendered and new observations contain no casualty counts. The score baseline no longer depends on casualty counters or their resets.

This does not erase AI Influence's previously stored conversation memories, or censor existing political report text supplied by Bellum Civile. Other mods and the AI's own context can still mention losses. It removes the bridge's aggregate casualty injection, not all possible sources of casualty claims.

## Retained behavior

- Captures Bellum political reports and supplies recent news and faction affiliations as context to AI Influence.
- Supplies BC war scores from the speaking side's perspective, descriptive standings, major score components and recorded pending resolution status.
- Keeps recent score movement and observed territorial endpoint comparisons. These are observations, not forecasts or automatic declarations of victory.
- Keeps source-attributed cached BC clan assessments and demands; no new grievance system or political decisions are introduced.
- Restricts detailed character briefings to wars involving that character's own kingdom. Neutral/unaffiliated characters get no detailed war briefing. Global dynamic-event context remains worldwide; ordinary political news keeps its existing sharing rules.
- Preserves the 0.2.3/0.3.3 chunking fix for both political reports and trend history. Each persisted chunk is at most 24,000 UTF-8 bytes and reassembly is checksum-validated. No full history is written to either legacy single-string key.

Score bands describe the current position, not victory probability. +/-100 is a decisive threshold, not proof that peace or surrender has completed. When BC score data is unavailable, the bridge labels it unavailable instead of inventing a value. BC's War & Peace Logic Revamp must be enabled and expose its tracker for those scores.

Trends use a seven-day rolling observation window by default, sampling approximately every six campaign hours plus the latest endpoint. A fresh history needs at least six campaign hours for an initial comparison. Current war data refreshes at session start, on relevant events and about every five seconds of application ticking. No update changes an AI request already in progress.

## Install or upgrade

1. Close Bannerlord and the launcher. Keep your current module and a known-working save as backups.
2. Replace `Modules\BellumAIEventBridge` with the module folder in this ZIP. Do not install Source or a second bridge module.
3. Keep the bridge after Bellum Civile and AI Influence, with Harmony enabled.
4. Keep your existing settings.json. Start the game and verify bridge.log identifies 0.3.4.
5. Load your working campaign, speak to a lord whose kingdom is at war, and inspect last-character-context.txt.
6. Save to a new slot, fully restart and reload to confirm your campaign works with this build.

Working 0.2.3 and 0.3.3 saves, plus repaired legacy saves, are supported by the unchanged persistence path. Readable old v1 report/trend data migrates. Already unreadable saves still require repair. This release does not modify AI Influence character files, parent-mod DLLs, or the user's uploaded saves. For a full rollback, restore the pre-upgrade module AND save.

## Settings

Located under your Windows Documents folder at `Mount and Blade II Bannerlord\Configs\BellumAIEventBridge\settings.json`. Existing settings remain in effect; missing fields use defaults. IncludeWarCasualties is obsolete and ignored even if true.

| Setting | Default | Purpose / accepted range |
|---|---:|---|
| Enabled | true | Master bridge switch. |
| IncludeWarBriefing | true | Add current-war context to both integrations. Set false to disable the entire new briefing while keeping existing news. |
| IncludeWarMotivations | true | Include stored clan target reasons, war will, and active pressures in the briefing. |
| IncludeWarTrends | true | Collect and inject recent war comparisons. Disabling clears collected trend history while preserving current war data and news. |
| WarTrendDays | 7 | Rolling comparison window in campaign days: **1–30**. Actual dates/duration are shown; increasing the setting cannot recover already discarded observations. |
| WarBriefingMaxCharacters | 4000 | Briefing limit: **1,000–8,000 characters**, also limited to half of the total prompt context budget and available space when injected. |
| WarBriefingMaxWars | 6 | Maximum wars considered per briefing: **1–12**. Fewer may fit. |
| ShareAllBellumUpdates | true | Broad capture and character eligibility; newest-first prompt selection; enables the direct-notification listener. |
| EnableCharacterKnowledge | true | Supplies context to character prompts. |
| ShowInjectionMessages | true | Shows the two news blurbs; does not hide startup status. |
| IncludePublicNotifications | true | Controls shared public-notification capture when broad sharing is OFF. |
| IncludePersonalNotifications | false | Controls shared player-directed capture when broad sharing is OFF. |
| IncludeFactionSnapshot | true | Includes the current rebel-faction snapshot in dynamic context. Character affiliation/local-faction facts are built separately while character integration is enabled. |
| WriteDiagnostics | true | Writes logs and diagnostic report/context files. |
| CharacterMaxPromptEvents | 24 | Character report limit: **1–24**. |
| CharacterMaxPromptCharacters | 10000 | Character bridge-context budget: **2,000–12,000 characters**. |
| RetentionDays | 30 | History age limit: **1–365 campaign days**. |
| MaxStoredEvents | 160 | Saved report limit: **10–500**. |
| MaxPromptEvents | 24 | Dynamic-event report limit: **1–80**. |
| MaxPromptCharacters | 10000 | Dynamic bridge-context budget: **2,000–24,000 characters**. |
| SnapshotMaxCharacters | 2500 | Dynamic faction-snapshot limit: **500–6,000 characters**, also capped at one-third of the dynamic context budget. |

The report journal defaults to 30 campaign days and 160 reports; the separate trend window remains bounded. Chunking does not add extra pruning or an unlimited archive. The defensive 64 MiB limit per serialized history remains; exceeding it fails saving rather than discarding data. Bad/missing chunks, integrity failures and unsupported trend schema block persistence rather than silently replacing history.

## Diagnostics and acceptance

- `bridge.log`: version, capture, integration and error messages.
- `last-character-context.txt`: exact latest speaker-specific injected bridge context; this is the file for checking kingdom scope and absence of structured casualty lines.
- `last-injected-context.txt`: latest global dynamic-event bridge injection.
- `last-war-briefing.txt`: worldwide war diagnostic, not a character-specific briefing.
- `last-captured-reports.json`: diagnostic copy of retained political reports; not an import source.

Check that current BC score and score movement remain, suffered/inflicted/combined casualty lines are absent, and unrelated wars do not appear in a lord's detailed briefing. Old conversation history can still influence what the AI says. Do not reset NPC history solely to install this update.

## Build and validation

Compiled module, source and regression fixtures are included. Rebuild with a .NET 8 SDK in PowerShell:

```powershell
.\Source\build.ps1 -GamePath 'F:\SteamLibrary\steamapps\common\Mount & Blade II Bannerlord'
```

The script builds the net472 module, runs both test suites, and writes `Source\dist\Modules\BellumAIEventBridge`. Automated tests cover existing political capture/prompt behavior, score perspective, kingdom filtering, trends, save safety and casualty removal. Explicit regression checks supply nonzero old counts and an enabled legacy setting to every briefing route and verify that no structured casualty values appear.

Live 0.3.4 game testing is still required. See VALIDATION.txt for exact build and test scope.
