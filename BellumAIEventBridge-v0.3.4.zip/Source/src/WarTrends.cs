using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using Newtonsoft.Json;

namespace BellumAIEventBridge
{
    public sealed class WarHolding
    {
        public string Id, Name, OwnerId;
    }
    // Only these plain summaries reach prompt workers; stored samples stay on the campaign thread.
    public sealed class WarTrend
    {
        public double FromDay, ToDay;
        public double? FirstScoreBefore, FirstScoreNow;
        public long? FirstAdditionalLosses, SecondAdditionalLosses;
        public string[] FirstGains, SecondGains;
    }
    public sealed class WarTrendPoint
    {
        public double Day;
        public double? Score;
        // Legacy 0.3.3 fields: read/preserve old observations, never collect or publish new counts.
        public long? LossesA, LossesB;
        public List<WarHolding> Holdings;
    }
    public sealed class WarTrendHistory
    {
        public string Key, SideA, SideB;
        public double StartedDay;
        public List<WarTrendPoint> Points = new List<WarTrendPoint>();
        public WarTrendPoint Last;
    }
    public sealed class WarTrendData
    {
        public int Version = 1;
        public List<WarTrendHistory> Wars = new List<WarTrendHistory>();
    }
    public sealed class WarTrendStore
    {
        public const int MaxHoldings = 512;
        public const int MaxWars = 64;
        public const double SampleDays = 0.25;
        private const double Epsilon = 0.000001;
        private Dictionary<string, WarTrendHistory> histories = new Dictionary<string, WarTrendHistory>();
        private static bool Finite(double d) { return !double.IsNaN(d) && !double.IsInfinity(d); }
        private static double? Score(double? d) { return d.HasValue && Finite(d.Value) && Math.Abs(d.Value) <= 100 ? d : null; }
        private static long? Losses(long? n) { return n.HasValue && n.Value >= 0 && n.Value <= int.MaxValue ? n : null; }
        private static List<WarHolding> CopyHoldings(List<WarHolding> input, string a, string b)
        {
            if (input == null || input.Count > MaxHoldings || input.Any(h => h == null || string.IsNullOrEmpty(h.Id) ||
                (h.OwnerId != a && h.OwnerId != b)) || input.Select(h => h.Id).Distinct().Count() != input.Count) return null;
            return input.Select(h => new WarHolding { Id = h.Id, Name = Journal.Clean(h.Name, 70), OwnerId = h.OwnerId }).ToList();
        }
        private static WarTrendPoint Point(WarState war, double day, string a)
        {
            bool flip = war.FirstId != a;
            return new WarTrendPoint { Day = day, Score = Score(war.FirstScore * (flip ? -1 : 1)),
                Holdings = CopyHoldings(war.Holdings, war.FirstId, war.SecondId) };
        }
        public void Observe(WarSnapshot snapshot, BridgeSettings settings)
        {
            if (!settings.Enabled || !settings.IncludeWarBriefing || !settings.IncludeWarTrends)
            {
                histories.Clear();
                if (snapshot != null) foreach (var w in snapshot.Wars) w.Trend = null;
                return;
            }
            // A failed read must not look like a concluded war. Nothing is published from it.
            if (snapshot == null || !Finite(snapshot.Day)) return;
            double day = snapshot.Day;
            var live = new HashSet<string>(snapshot.Wars.Select(w => w.Key));
            foreach (var key in histories.Keys.Where(k => !live.Contains(k)).ToList()) histories.Remove(key);
            foreach (var war in snapshot.Wars.OrderByDescending(w => w.Involves(snapshot.PlayerKingdomId)).ThenBy(w => w.Key, StringComparer.Ordinal))
            {
                war.Trend = null;
                if (string.IsNullOrEmpty(war.Key) || string.IsNullOrEmpty(war.FirstId) || string.IsNullOrEmpty(war.SecondId) ||
                    war.FirstId == war.SecondId || !Finite(war.StartedDay) || war.StartedDay > day + Epsilon) continue;
                histories.TryGetValue(war.Key, out var h);
                bool reset = h == null || Math.Abs(h.StartedDay - war.StartedDay) > Epsilon ||
                    !war.Involves(h.SideA) || !war.Involves(h.SideB) || h.Last.Day > day + Epsilon;
                if (reset)
                {
                    if (h == null && histories.Count >= MaxWars) continue;
                    h = new WarTrendHistory { Key = war.Key, SideA = war.FirstId, SideB = war.SecondId, StartedDay = war.StartedDay };
                    histories[war.Key] = h;
                }
                var point = Point(war, day, h.SideA);
                h.Points.RemoveAll(p => p.Day < day - settings.WarTrendDays - Epsilon || p.Day > day + Epsilon);
                // Endpoints come from actual observations, never interpolated or backfilled.
                if (h.Points.Count == 0 || day - h.Points[h.Points.Count - 1].Day >= SampleDays - Epsilon) h.Points.Add(point);
                h.Last = point;
                var baseline = h.Points.FirstOrDefault(p => day - p.Day >= SampleDays - Epsilon &&
                    (!point.Score.HasValue || p.Score.HasValue));
                if (baseline == null) continue;
                bool reverse = war.FirstId != h.SideA;
                double sign = reverse ? -1 : 1;
                var trend = new WarTrend { FromDay = baseline.Day, ToDay = day,
                    FirstScoreBefore = baseline.Score * sign, FirstScoreNow = point.Score * sign };
                if (baseline.Holdings != null && point.Holdings != null)
                {
                    var old = baseline.Holdings.ToDictionary(v => v.Id);
                    var changed = point.Holdings.Where(v => old.TryGetValue(v.Id, out var previous) && previous.OwnerId != v.OwnerId).ToList();
                    trend.FirstGains = changed.Where(v => v.OwnerId == war.FirstId).OrderBy(v => v.Id, StringComparer.Ordinal).Select(v => v.Name).ToArray();
                    trend.SecondGains = changed.Where(v => v.OwnerId == war.SecondId).OrderBy(v => v.Id, StringComparer.Ordinal).Select(v => v.Name).ToArray();
                }
                war.Trend = trend;
            }
        }
        public string Save()
        { return JsonConvert.SerializeObject(new WarTrendData { Wars = histories.Values.OrderBy(h => h.Key, StringComparer.Ordinal).ToList() }); }
        public void Load(string json)
        {
            if (string.IsNullOrWhiteSpace(json)) { histories.Clear(); return; }
            var data = JsonConvert.DeserializeObject<WarTrendData>(json);
            if (data == null || data.Version != 1 || data.Wars == null)
                throw new InvalidDataException("Unsupported or damaged war trend history.");
            var restored = new Dictionary<string, WarTrendHistory>();
            foreach (var h in data.Wars.Take(MaxWars))
            {
                if (h == null || string.IsNullOrEmpty(h.Key) || string.IsNullOrEmpty(h.SideA) || string.IsNullOrEmpty(h.SideB) ||
                    h.SideA == h.SideB || !Finite(h.StartedDay) || h.Last == null || !Finite(h.Last.Day) || h.Last.Day < h.StartedDay || h.Points == null) continue;
                h.Points = h.Points.Where(p => p != null && Finite(p.Day) && p.Day >= h.StartedDay &&
                    p.Day <= h.Last.Day && p.Day >= h.Last.Day - 30).OrderBy(p => p.Day)
                    .GroupBy(p => p.Day).Select(g => g.Last()).TakeLastCompat(122).ToList();
                foreach (var p in h.Points.Concat(new[] { h.Last }))
                {
                    p.Score = Score(p.Score); p.LossesA = Losses(p.LossesA); p.LossesB = Losses(p.LossesB);
                    p.Holdings = CopyHoldings(p.Holdings, h.SideA, h.SideB);
                }
                restored[h.Key] = h;
            }
            histories = restored;
        }
    }
    public static class WarTrends
    {
        private static string Day(double n) { return n.ToString("F2", CultureInfo.InvariantCulture); }
        public static string Render(WarState war, bool reverse, BridgeSettings settings, int budget)
        {
            if (!settings.IncludeWarTrends || budget <= 0) return "";
            var t = war.Trend;
            string pending = "  War trend: collecting comparable history (at least 0.25 campaign days required), or history unavailable; do not infer earlier momentum.";
            if (t == null) return pending.Length <= budget ? pending : "";
            var sb = new StringBuilder();
            string header = "  OBSERVED WAR TREND, days " + Day(t.FromDay) + " to " + Day(t.ToDay) + " (" + Day(t.ToDay - t.FromDay) + " days; target window " + settings.WarTrendDays + " days). Endpoint comparison, not a forecast or proof of cause.";
            if (header.Length + 100 > budget) return "";
            sb.Append(header);
            int details = 0;
            Action<string> line = value => { if (sb.Length + Environment.NewLine.Length + value.Length <= budget) { sb.AppendLine(); sb.Append(value); details++; } };
            string own = Journal.Clean(reverse ? war.SecondName : war.FirstName, 70), enemy = Journal.Clean(reverse ? war.FirstName : war.SecondName, 70);
            double sign = reverse ? -1 : 1;
            if (t.FirstScoreBefore.HasValue && t.FirstScoreNow.HasValue)
            {
                double before = Math.Round(t.FirstScoreBefore.Value * sign, 1, MidpointRounding.AwayFromZero);
                double now = Math.Round(t.FirstScoreNow.Value * sign, 1, MidpointRounding.AwayFromZero);
                double change = now - before;
                string direction = change >= 0.05 ? "position improved" : change <= -0.05 ? "position worsened" : "unchanged at displayed precision";
                line("    " + own + " score " + WarKnowledge.Number(before) + " -> " + WarKnowledge.Number(now) + " (" + WarKnowledge.Number(change) + " points; " + direction + "). " + enemy + " has the opposite score change.");
            }
            else line("    Comparable BC score history unavailable; do not invent earlier momentum.");
            if (t.FirstGains != null && t.SecondGains != null)
            {
                string[] gains = reverse ? t.SecondGains : t.FirstGains, losses = reverse ? t.FirstGains : t.SecondGains;
                // Count all endpoint differences; a bounded list of names supplies local context.
                string names = string.Join("; ", gains.Take(2).Select(n => Journal.Clean(n, 45) + " now " + own)
                    .Concat(losses.Take(2).Select(n => Journal.Clean(n, 45) + " now " + enemy)));
                string core = "    Towns/castles with opposite-side control at the endpoints: " + own + " gained " + gains.Length + ", lost " + losses.Length + ". Net changes only; intermediate recaptures, third-party transfers and causes are not established.";
                if (names.Length > 0 && sb.Length + Environment.NewLine.Length + core.Length + names.Length + 3 <= budget) core += " " + names + ".";
                line(core);
            }
            else line("    Comparable territorial observations unavailable.");
            return details == 0 ? "" : sb.ToString();
        }
    }
}
