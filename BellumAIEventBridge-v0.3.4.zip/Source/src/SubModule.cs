using System;
using TaleWorlds.CampaignSystem;
using TaleWorlds.Core;
using TaleWorlds.MountAndBlade;

namespace BellumAIEventBridge
{
    public sealed class SubModule : MBSubModuleBase
    {
        protected override void OnSubModuleLoad()
        {
            base.OnSubModuleLoad();
            Diagnostics.Initialize();
            Diagnostics.Log("Bellum AI Event Bridge 0.3.4 loaded; target Bannerlord 1.4.5 / BC 1.2.7 / AI Influence 6.0.0.");
        }
        protected override void OnGameStart(Game game, IGameStarter starter)
        {
            base.OnGameStart(game, starter);
            BridgeBehavior.Current?.Stop();
            BridgeBehavior.Current = null;
            if (game.GameType is Campaign && starter is CampaignGameStarter campaignStarter)
            {
                Hooks.Install();
                var behavior = new BridgeBehavior();
                BridgeBehavior.Current = behavior;
                campaignStarter.AddBehavior(behavior);
            }
        }
        public override void OnGameEnd(Game game)
        {
            BridgeBehavior.Current?.Stop();
            BridgeBehavior.Current = null;
            base.OnGameEnd(game);
        }
        protected override void OnApplicationTick(float dt)
        {
            base.OnApplicationTick(dt);
            // Application ticks continue during paused conversations; campaign
            // simulation ticks are not a reliable place to display AI callbacks.
            try
            {
                BridgeBehavior.Current?.Maintain(dt);
                BridgeBehavior.Current?.FlushNotices();
            }
            catch (Exception e) { Diagnostics.Log("Injection notice could not be displayed: " + e.GetType().Name); }
        }
        protected override void OnSubModuleUnloaded()
        {
            BridgeBehavior.Current?.Stop();
            BridgeBehavior.Current = null;
            Hooks.Remove();
            base.OnSubModuleUnloaded();
        }
    }
}
