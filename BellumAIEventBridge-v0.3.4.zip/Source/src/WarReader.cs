using System;
using System.Collections;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Reflection;
using TaleWorlds.CampaignSystem;

namespace BellumAIEventBridge
{
    // Only called on the application/campaign thread. No BC decision, scoring,
    // GetWarWill or debug-report methods are invoked: some mutate BC caches.
    internal static class WarReader
    {
        private static bool detailErrorLogged;
        private static object Get(object source, string name) { return BellumReader.Get(source, name); }
        private static string Str(object source, string name) { return Get(source, name)?.ToString() ?? ""; }
        private static IEnumerable<object> Items(object source) { return (source as IEnumerable)?.Cast<object>() ?? Enumerable.Empty<object>(); }
        private static double? Number(object value)
        {
            if (value == null) return null;
            double d = Convert.ToDouble(value, CultureInfo.InvariantCulture);
            return double.IsNaN(d) || double.IsInfinity(d) ? (double?)null : d;
        }
        private static object Behavior(Assembly assembly, string name)
        {
            var type = assembly?.GetType("BellumCivile.Behaviors." + name);
            if (type == null || Campaign.Current == null) return null;
            var method = typeof(Campaign).GetMethods().First(m => m.Name == "GetCampaignBehavior" && m.IsGenericMethodDefinition && m.GetParameters().Length == 0);
            return method.MakeGenericMethod(type).Invoke(Campaign.Current, null);
        }
        private static string Pair(string first, string second)
        { return string.CompareOrdinal(first, second) <= 0 ? first + "/" + second : second + "/" + first; }
        private static object StaticOption(Type type, string name)
        { return type?.GetProperty(name, BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Static)?.GetValue(null, null); }

        internal static WarSnapshot Read(BridgeSettings settings)
        {
            var result = new WarSnapshot { Day = CampaignTime.Now.ToDays, PlayerKingdomId = Clan.PlayerClan?.Kingdom?.StringId };
            if (!settings.IncludeWarBriefing || Campaign.Current == null) return result;
            var kingdoms = Kingdom.All.Where(k => k != null && !k.IsEliminated).ToDictionary(k => k.StringId);
            var assembly = AppDomain.CurrentDomain.GetAssemblies().FirstOrDefault(a => a.GetName().Name == "BellumCivile");
            var options = assembly?.GetType("BellumCivile.BellumCivileOptions");
            bool revamp = StaticOption(options, "EnableWarPeaceLogicRevamp") is bool enabled && enabled;
            object scoreBehavior = revamp ? Behavior(assembly, "WarScoreBehavior") : null;
            var active = Items(Get(scoreBehavior, "_wars")).Where(w => BellumReader.Flag(w, "IsActive"))
                .GroupBy(w => Pair(Str(w, "AttackerKingdomId"), Str(w, "DefenderKingdomId")))
                .ToDictionary(g => g.Key, g => g.OrderByDescending(w => Number(Get(w, "StartedDay")) ?? 0).First());
            var seen = new HashSet<string>();
            foreach (var kingdom in kingdoms.Values)
            {
                // Existing enemies only: do not create neutral stances for arbitrary pairs.
                foreach (var enemy in kingdom.FactionsAtWarWith.OfType<Kingdom>())
                {
                    if (enemy.IsEliminated || !kingdoms.ContainsKey(enemy.StringId)) continue;
                    string key = Pair(kingdom.StringId, enemy.StringId);
                    if (!seen.Add(key)) continue;
                    var stance = kingdom.GetStanceWith(enemy);
                    if (stance == null || !stance.IsAtWar) continue;
                    double began = stance.WarStartDate.ToDays;
                    active.TryGetValue(key, out var record);
                    // An old BC tracker must not supply a previous war's score.
                    if (record != null && (Number(Get(record, "StartedDay")) ?? double.NegativeInfinity) < began - 0.05) record = null;
                    Kingdom first = kingdom, second = enemy;
                    if (record != null)
                    {
                        if (!kingdoms.TryGetValue(Str(record, "AttackerKingdomId"), out first) ||
                            !kingdoms.TryGetValue(Str(record, "DefenderKingdomId"), out second)) continue;
                    }
                    var war = new WarState {
                        Key = key, FirstId = first.StringId, FirstName = Journal.Clean(first.Name?.ToString(), 90),
                        SecondId = second.StringId, SecondName = Journal.Clean(second.Name?.ToString(), 90),
                        FirstRulingClanId = first.RulingClan?.StringId, SecondRulingClanId = second.RulingClan?.StringId,
                        StartedDay = began, HasBellumRecord = record != null,
                        ConflictType = record == null ? "unclassified kingdom war" : Str(record, "ConflictType"),
                        FirstScore = Number(Get(record, "Score"))
                    };
                    foreach (var component in new[] {
                        new[] { "OccupationScore", "territorial control" }, new[] { "BattleScore", "battle advantage" },
                        new[] { "RaidScore", "raiding" }, new[] { "PrisonerScore", "prisoner leverage" },
                        new[] { "TickingScore", "campaign momentum" }, new[] { "ObjectiveScore", "claim objective" },
                        new[] { "LandlessPressureScore", "landless pressure" } })
                    {
                        var value = Number(Get(record, component[0]));
                        if (value.HasValue) war.Components[component[1]] = value.Value;
                    }
                    if (BellumReader.Flag(record, "ParleyPending")) war.Resolution = BellumReader.Flag(record, "ParleyForced") ? "forced peace talks pending; no completed treaty established" : "peace talks pending";
                    else if (BellumReader.Flag(record, "ResolutionPending") || BellumReader.Flag(record, "TerminalResolutionQueued")) war.Resolution = "decisive resolution pending; no completed settlement established";
                    else if (BellumReader.Flag(record, "WhitePeaceOfferPending")) war.Resolution = "white-peace offer pending";
                    result.Wars.Add(war);
                }
            }
            if (result.Wars.Count == 0) return result;
            if (settings.IncludeWarTrends)
            {
                try
                {
                    var holdings = TaleWorlds.CampaignSystem.Settlements.Settlement.All
                        .Where(s => s.IsTown || s.IsCastle)
                        .Select(s => new WarHolding { Id = s.StringId, Name = Journal.Clean(s.Name?.ToString(), 70),
                            OwnerId = (s.MapFaction as Kingdom)?.StringId }).ToList();
                    foreach (var war in result.Wars)
                    {
                        var owned = holdings.Where(h => war.Involves(h.OwnerId)).ToList();
                        // Null means incomplete/unavailable, never an empty realm.
                        if (owned.Count <= WarTrendStore.MaxHoldings) war.Holdings = owned;
                    }
                }
                catch { /* Optional territorial data cannot block scores or news. */ }
            }
            try
            {
                var manager = Behavior(assembly, "FactionManagerBehavior");
                foreach (var faction in Items(Get(manager, "_activeFactions")))
                {
                    if (BellumReader.Flag(faction, "IsIdeology")) continue;
                    string rebel = (Get(faction, "_rebelKingdom") as Kingdom)?.StringId ?? Str(faction, "_rebelKingdomStringId");
                    string parent = (Get(faction, "ParentKingdom") as Kingdom)?.StringId;
                    var war = result.Wars.FirstOrDefault(w => w.Involves(rebel) && w.Involves(parent));
                    if (war != null) war.RecordedDemand = Journal.Clean(Str(faction, "Type"), 100);
                }
                if (settings.IncludeWarMotivations && revamp)
                    ReadAssessments(result, Behavior(assembly, "WarPeaceRevampBehavior"), options);
                detailErrorLogged = false;
            }
            catch (Exception e)
            {
                if (!detailErrorLogged) Diagnostics.Log("War motive details unavailable; scores remain available: " + e);
                detailErrorLogged = true;
            }
            return result;
        }

        private static void ReadAssessments(WarSnapshot result, object behavior, Type options)
        {
            if (behavior == null) return;
            var will = Get(behavior, "_warWillByClanId") as IDictionary;
            var targets = Get(behavior, "_targetScoresByClanId") as IDictionary;
            var pressures = Items(Get(behavior, "_pressureRecords"))
                .Where(p => BellumReader.Flag(p, "IsActive") &&
                    (!(Number(Get(p, "ExpiresDay")) is double end) || end <= 0 || end > result.Day) &&
                    (Number(Get(p, "CreatedDay")) ?? 0) <= result.Day + 0.01)
                .GroupBy(p => Str(p, "ClanId")).ToDictionary(g => g.Key, g => g.ToList());
            foreach (var clan in Clan.All)
            {
                if (clan == null || clan.IsEliminated || clan.Kingdom == null || !result.Wars.Any(w => w.Involves(clan.Kingdom.StringId))) continue;
                var entry = new WarClanAssessment { ClanId = clan.StringId, ClanName = Journal.Clean(clan.Name?.ToString(), 70), KingdomId = clan.Kingdom.StringId,
                    WarWill = will != null && will.Contains(clan.StringId) ? Number(will[clan.StringId]) : null,
                    PeaceThreshold = Number(StaticOption(options, "WarWillPeaceThreshold")) ?? 25,
                    WarThreshold = Number(StaticOption(options, "WarWillDeclareThreshold")) ?? 75 };
                if (targets != null && targets.Contains(clan.StringId))
                {
                    foreach (var target in Items(targets[clan.StringId]))
                    {
                        var realm = Get(target, "TargetKingdom") as Kingdom;
                        if (realm == null || !result.Wars.Any(w => w.Involves(entry.KingdomId) && w.Involves(realm.StringId))) continue;
                        // Keep all reasons as plain data; formatter applies a small prompt cap.
                        entry.TargetReasons[realm.StringId] = Items(Get(target, "Reasons"))
                            .Select(v => Journal.Clean(v?.ToString(), 160)).Where(s => s.Length > 0 && !s.StartsWith("active war +", StringComparison.Ordinal)).Take(10).ToArray();
                    }
                }
                if (pressures.TryGetValue(clan.StringId, out var records))
                {
                    foreach (var group in records.GroupBy(p => Str(p, "TargetKingdomId")))
                    {
                        if (!result.Wars.Any(w => w.Involves(entry.KingdomId) && w.Involves(group.Key))) continue;
                        entry.Pressures[group.Key] = group.OrderByDescending(p => Math.Abs(Number(Get(p, "Amount")) ?? 0))
                            .Take(5).Select(p => Journal.Clean(Str(p, "Reason"), 120) + " (war-will effect " +
                                WarKnowledge.Number(Number(Get(p, "Amount")) ?? 0) + PressureContext(p) + ")").ToArray();
                    }
                }
                if (entry.WarWill.HasValue || entry.TargetReasons.Count > 0 || entry.Pressures.Count > 0) result.Clans[entry.ClanId] = entry;
            }
        }
        private static string PressureContext(object pressure)
        {
            string settlementId = Str(pressure, "ContextSettlementId");
            if (settlementId.Length == 0) return "";
            var settlement = TaleWorlds.CampaignSystem.Settlements.Settlement.All.FirstOrDefault(s => s.StringId == settlementId);
            return settlement == null ? "" : "; " + Journal.Clean(settlement.Name?.ToString(), 80);
        }
    }
}
