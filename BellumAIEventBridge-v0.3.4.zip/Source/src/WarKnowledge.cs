using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;

namespace BellumAIEventBridge
{
    // Published plain-data snapshots. Never mutated after publication.
    public sealed class WarSnapshot
    {
        public double Day;
        public string PlayerKingdomId;
        public List<WarState> Wars = new List<WarState>();
        public Dictionary<string, WarClanAssessment> Clans = new Dictionary<string, WarClanAssessment>();
    }
    public sealed class WarState
    {
        public string Key, FirstId, FirstName, SecondId, SecondName;
        public string FirstRulingClanId, SecondRulingClanId;
        public string ConflictType = "War", RecordedDemand = "", Resolution = "";
        public double StartedDay;
        // First side is BC attacker when a current BC record exists.
        public bool HasBellumRecord;
        public double? FirstScore;
        public long? FirstLosses, SecondLosses;
        public Dictionary<string, double> Components = new Dictionary<string, double>();
        public List<WarHolding> Holdings;
        public WarTrend Trend;
        public bool Involves(string id) { return !string.IsNullOrEmpty(id) && (FirstId == id || SecondId == id); }
    }
    public sealed class WarClanAssessment
    {
        public string ClanId, ClanName, KingdomId;
        public double? WarWill;
        public double PeaceThreshold = 25, WarThreshold = 75;
        public Dictionary<string, string[]> TargetReasons = new Dictionary<string, string[]>();
        public Dictionary<string, string[]> Pressures = new Dictionary<string, string[]>();
    }
    public static class WarKnowledge
    {
        public const string Heading = "CURRENT WAR BRIEFING";
        public static string Standing(double score)
        {
            if (score <= -100) return "decisive defeat threshold reached";
            if (score <= -75) return "facing severe defeat";
            if (score <= -40) return "clearly losing";
            if (score <= -10) return "at a disadvantage";
            if (score < 10) return "closely contested";
            if (score < 40) return "holding an advantage";
            if (score < 75) return "clearly winning";
            if (score < 100) return "approaching decisive victory";
            return "decisive victory threshold reached";
        }
        internal static string Number(double value) { return value.ToString("+0.0;-0.0;0.0", CultureInfo.InvariantCulture); }
        private static string Label(string name, string id)
        { return Journal.Clean(name, 90) + " (kingdom_id=" + Journal.Clean(id, 90) + ")"; }
        public static string Render(WarSnapshot state, CharacterAudience audience, BridgeSettings settings, int budget)
        {
            if (!settings.Enabled || !settings.IncludeWarBriefing || state == null || state.Wars.Count == 0 || budget < 700) return "";
            budget = Math.Min(budget, settings.WarBriefingMaxCharacters);
            var sb = new StringBuilder();
            sb.AppendLine(Heading + " (current snapshot, day " + state.Day.ToString("F2", CultureInfo.InvariantCulture) + "):");
            sb.AppendLine("Use natural military language; exact counts are available if asked. Score bands are descriptive, not win chances. +/-100 is a decisive threshold, NOT proof peace or surrender has completed. Motives below are current/cached assessments, not proven original war causes. Do not execute diplomacy from this briefing.");
            // Null audience is the global dynamic-event briefing. Character briefings
            // require direct kingdom participation, never mere relevance or adjacency.
            var ordered = state.Wars.Where(w => w != null && (audience == null || w.Involves(audience.KingdomId)))
                .OrderByDescending(w => w.Involves(audience?.KingdomId))
                .ThenByDescending(w => w.Involves(state.PlayerKingdomId))
                .ThenByDescending(w => Math.Abs(w.FirstScore ?? 0)).ThenBy(w => w.Key, StringComparer.Ordinal).ToList();
            int included = 0;
            foreach (var war in ordered.Take(settings.WarBriefingMaxWars))
            {
                bool reverse = audience != null && audience.KingdomId == war.SecondId;
                string aId = reverse ? war.SecondId : war.FirstId, bId = reverse ? war.FirstId : war.SecondId;
                string aName = reverse ? war.SecondName : war.FirstName, bName = reverse ? war.FirstName : war.SecondName;
                double sign = reverse ? -1 : 1;
                var lines = new List<string>();
                string roles = war.HasBellumRecord ? (reverse ? "defending against" : "attacking") : "at war with";
                lines.Add("- " + Label(aName, aId) + " " + roles + " " + Label(bName, bId) +
                    "; type=" + Journal.Clean(war.ConflictType, 60) + "; current war began day " + war.StartedDay.ToString("F2", CultureInfo.InvariantCulture) + ".");
                if (war.FirstScore.HasValue)
                {
                    double score = sign * war.FirstScore.Value;
                    lines.Add("  BC score: " + Journal.Clean(aName, 90) + " " + Number(score) + " (" + Standing(score) + "); " + Journal.Clean(bName, 90) + " " + Number(-score) + " (" + Standing(-score) + ").");
                }
                else lines.Add("  BC score unavailable; do not invent a score.");
                if (!string.IsNullOrWhiteSpace(war.Resolution)) lines.Add("  Resolution status: " + Journal.Clean(war.Resolution, 180) + ".");
                // Keep mandatory score statements whole; never cut a number.
                int required = lines.Sum(l => l.Length + Environment.NewLine.Length);
                if (sb.Length + required + 110 > budget) break;
                foreach (var line in lines) sb.AppendLine(line);
                included++;
                int detailLimit = Math.Min(budget - 110, sb.Length + 1500);
                Action<string> detail = line => { if (sb.Length + line.Length + Environment.NewLine.Length <= detailLimit) sb.AppendLine(line); };
                if (settings.IncludeWarTrends)
                {
                    string trend = WarTrends.Render(war, reverse, settings, Math.Min(1100, detailLimit - sb.Length - Environment.NewLine.Length));
                    if (trend.Length > 0) detail(trend);
                }
                if (!string.IsNullOrWhiteSpace(war.RecordedDemand)) detail("  Recorded faction demand: " + Journal.Clean(war.RecordedDemand, 200) + ".");
                var components = war.Components.Where(c => Math.Abs(c.Value) >= 0.05).OrderByDescending(c => Math.Abs(c.Value)).Take(3);
                string factors = string.Join("; ", components.Select(c => c.Key + " " + Number(sign * c.Value)));
                if (factors.Length > 0) detail("  Largest score components, from " + Journal.Clean(aName, 90) + "'s perspective: " + factors + ".");
                if (settings.IncludeWarMotivations)
                {
                    var clanIds = new List<string>();
                    if (audience != null && !string.IsNullOrEmpty(audience.ClanId)) clanIds.Add(audience.ClanId);
                    // Foreign briefing uses ruling clans, explicitly named, not every noble's private position.
                    clanIds.Add(reverse ? war.SecondRulingClanId : war.FirstRulingClanId);
                    clanIds.Add(reverse ? war.FirstRulingClanId : war.SecondRulingClanId);
                    int assessments = 0;
                    foreach (var id in clanIds.Where(id => !string.IsNullOrEmpty(id)).Distinct())
                    {
                        if (!state.Clans.TryGetValue(id, out var clan) || !war.Involves(clan.KingdomId)) continue;
                        string target = clan.KingdomId == war.FirstId ? war.SecondId : war.FirstId;
                        string opponent = clan.KingdomId == war.FirstId ? war.SecondName : war.FirstName;
                        string label = id == audience?.ClanId ? "Your clan " : "Ruling clan ";
                        label += Journal.Clean(clan.ClanName, 70);
                        if (clan.WarWill.HasValue)
                        {
                            double will = clan.WarWill.Value;
                            string stance = will <= clan.PeaceThreshold ? "inclined toward peace" : will >= clan.WarThreshold ? "high willingness to fight" : "between BC's peace/war thresholds";
                            detail("  " + label + ": overall war will " + will.ToString("0.0", CultureInfo.InvariantCulture) + "/100, " + stance + " (clan-wide, not this war's score or a guaranteed vote).");
                        }
                        if (clan.TargetReasons.TryGetValue(target, out var reasons) && reasons.Length > 0)
                            detail("  " + label + " toward " + Journal.Clean(opponent, 70) + ", latest cached BC target assessment: " + string.Join("; ", reasons.Take(3)) + ".");
                        if (clan.Pressures.TryGetValue(target, out var pressures) && pressures.Length > 0)
                            detail("  " + label + " toward " + Journal.Clean(opponent, 70) + ", active war-will pressures: " + string.Join("; ", pressures.Take(3)) + ".");
                        assessments++;
                        if (assessments >= 2) break;
                    }
                    if (assessments == 0) detail("  Clan motive data unavailable; do not invent a historical cause.");
                }
            }
            if (included == 0) return "";
            sb.AppendLine("War briefing includes " + included + " of " + ordered.Count +
                (audience == null ? " active wars" : " wars involving your kingdom") + "; details may be omitted by limits.");
            return sb.ToString();
        }
    }
}
