using System;
using System.IO;
using System.Text;
using Newtonsoft.Json;

namespace BellumAIEventBridge
{
    internal static class Diagnostics
    {
        private static readonly object Gate = new object();
        public static readonly string DirectoryPath = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments), "Mount and Blade II Bannerlord", "Configs", "BellumAIEventBridge");
        public static BridgeSettings Settings { get; private set; } = new BridgeSettings();
        public static void Initialize()
        {
            try
            {
                Directory.CreateDirectory(DirectoryPath);
                string file = Path.Combine(DirectoryPath, "settings.json");
                if (File.Exists(file)) Settings = JsonConvert.DeserializeObject<BridgeSettings>(File.ReadAllText(file)) ?? new BridgeSettings();
                Settings.Normalize();
                if (!File.Exists(file)) File.WriteAllText(file, JsonConvert.SerializeObject(Settings, Formatting.Indented));
            }
            catch (Exception e) { Log("Settings could not be read; using defaults: " + e.GetType().Name); }
        }
        public static void Log(string message)
        {
            if (!Settings.WriteDiagnostics) return;
            try
            {
                lock (Gate)
                {
                    Directory.CreateDirectory(DirectoryPath);
                    var path = Path.Combine(DirectoryPath, "bridge.log");
                    if (File.Exists(path) && new FileInfo(path).Length > 1024 * 1024) File.WriteAllText(path, "Log rotated.\n");
                    File.AppendAllText(path, DateTime.UtcNow.ToString("o") + " " + message + Environment.NewLine, Encoding.UTF8);
                }
            }
            catch { /* Diagnostics must never interrupt a campaign or an AI request. */ }
        }
        public static void WriteContext(string context)
        { WriteContextFile("last-injected-context.txt", context); }
        public static void WriteCharacterContext(string context)
        { WriteContextFile("last-character-context.txt", context); }
        public static void WriteCapturedReports(string json)
        { WriteContextFile("last-captured-reports.json", json); }
        public static void WriteWarBriefing(string text)
        { WriteContextFile("last-war-briefing.txt", string.IsNullOrWhiteSpace(text) ? "No active wars fit the current briefing (or no active wars exist)." : text); }
        private static void WriteContextFile(string name, string context)
        {
            if (!Settings.WriteDiagnostics) return;
            try
            {
                lock (Gate)
                {
                    Directory.CreateDirectory(DirectoryPath);
                    File.WriteAllText(Path.Combine(DirectoryPath, name), context, Encoding.UTF8);
                }
            }
            catch { }
        }
    }
}
