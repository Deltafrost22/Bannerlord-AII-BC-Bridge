using System;
using System.Globalization;
using System.Security.Cryptography;
using System.Text;
using System.Threading;
using System.Collections.Generic;
using System.Collections.Concurrent;
using TaleWorlds.CampaignSystem;
using TaleWorlds.Library;

namespace BellumAIEventBridge
{
    public sealed class BridgeBehavior : CampaignBehaviorBase
    {
        internal static volatile BridgeBehavior Current;
        private readonly Journal journal = new Journal(Diagnostics.Settings);
        private bool persistenceFault;
        private readonly WarTrendStore warTrends = new WarTrendStore();
        private volatile bool ready;
        private bool dirty = true;
        private string snapshot = "";
        private float tickSeconds;
        private int lastHour = -1;
        private float warRefreshSeconds;
        private bool warReadErrorLogged;
        private bool warsDirty;
        private string lastWarStatus;
        private string publishedContext = "";
        private int injections;
        private bool snapshotErrorLogged;
        private bool audienceErrorLogged;
        private Dictionary<Hero, CharacterAudience> audiences = new Dictionary<Hero, CharacterAudience>();
        private readonly InjectionNotices notices = new InjectionNotices();
        private int characterInjections;
        private readonly ConcurrentQueue<string> directNotifications = new ConcurrentQueue<string>();
        internal string Context => Volatile.Read(ref publishedContext);
        public override void RegisterEvents()
        {
            CampaignEvents.OnSessionLaunchedEvent.AddNonSerializedListener(this, OnSession);
            CampaignEvents.MapEventEnded.AddNonSerializedListener(this, _ => warsDirty = true);
            CampaignEvents.WarDeclared.AddNonSerializedListener(this, (a, b, detail) => warsDirty = true);
            CampaignEvents.MakePeace.AddNonSerializedListener(this, (a, b, detail) => warsDirty = true);
            CampaignEvents.OnSettlementOwnerChangedEvent.AddNonSerializedListener(this, (s, claim, newOwner, oldOwner, capturer, detail) => warsDirty = true);
            CampaignEvents.OnClanChangedKingdomEvent.AddNonSerializedListener(this, (clan, oldKingdom, newKingdom, detail, notify) => dirty = true);
        }
        public override void SyncData(IDataStore store)
        {
            try
            {
                if (store.IsSaving)
                {
                    if (persistenceFault) throw new System.IO.InvalidDataException("Bridge history was not loaded safely; refusing to overwrite it.");
                    string reports = journal.Save(), trends = warTrends.Save();
                    // Validate both payloads before the first store mutation.
                    JournalPersistence.Split(reports);
                    JournalPersistence.Split(trends);
                    JournalPersistence.Save(store.SyncData<string>, reports);
                    WarTrendPersistence.Save(store.SyncData<string>, trends);
                }
                else if (store.IsLoading)
                {
                    persistenceFault = true;
                    journal.Load(JournalPersistence.Load(store.SyncData<string>));
                    warTrends.Load(WarTrendPersistence.Load(store.SyncData<string>));
                    persistenceFault = false;
                }
            }
            catch (Exception e)
            {
                Diagnostics.Log("Bridge history persistence failed; history was NOT reset: " + e);
                throw;
            }
        }
        private void OnSession(CampaignGameStarter starter)
        {
            Current = this;
            Hooks.Install();
            ready = !persistenceFault && Diagnostics.Settings.Enabled && Hooks.SummaryReady && (Hooks.PromptReady || Hooks.CharacterReady);
            Refresh();
            Diagnostics.WriteContext("No context has been injected in this campaign session yet.");
            Diagnostics.WriteCharacterContext("No character knowledge has been injected in this campaign session yet.");
            Diagnostics.Log("Campaign session opened; retained reports=" + journal.Count + "; ready=" + ready);
            Diagnostics.WriteCapturedReports(journal.Save());
            InformationManager.DisplayMessage(new InformationMessage(ready
                ? "[Bellum AI Bridge] Ready. Dynamic events: " + (Hooks.PromptReady ? "ON" : "unavailable") +
                    "; character knowledge: " + (Hooks.CharacterReady && Diagnostics.Settings.EnableCharacterKnowledge ? "ON" : "OFF/unavailable") + "."
                : "[Bellum AI Bridge] Inactive. Check settings.json and bridge.log in Configs/BellumAIEventBridge."));
        }
        internal void Maintain(float dt)
        {
            if (!ready) return;
            while (directNotifications.TryDequeue(out var message))
            {
                string key = "direct/" + Math.Floor(CampaignTime.Now.ToDays).ToString(CultureInfo.InvariantCulture) + "/" + Hash(message);
                Record(key, "DirectNotification", message, false);
            }
            tickSeconds += dt;
            warRefreshSeconds += dt;
            if (tickSeconds < 1) return;
            tickSeconds = 0;
            var hour = (int)(CampaignTime.Now.ToDays * 24);
            if (dirty || hour != lastHour) { lastHour = hour; Refresh(); }
            else if (warsDirty || warRefreshSeconds >= 5) RefreshWars();
        }
        private void Refresh()
        {
            if (!ready) { Volatile.Write(ref publishedContext, ""); return; }
            try
            {
                snapshot = Diagnostics.Settings.IncludeFactionSnapshot ? BellumReader.Snapshot() : "";
                snapshotErrorLogged = false;
            }
            catch (Exception e)
            {
                snapshot = "";
                if (!snapshotErrorLogged) Diagnostics.Log("Faction snapshot unavailable; report capture continues: " + e.GetType().Name);
                snapshotErrorLogged = true;
            }
            journal.Update(CampaignTime.Now.ToDays, snapshot);
            RefreshWars();
            if (Diagnostics.Settings.EnableCharacterKnowledge && Hooks.CharacterReady)
            {
                try
                {
                    Volatile.Write(ref audiences, BellumReader.BuildAudiences());
                    audienceErrorLogged = false;
                }
                catch (Exception e)
                {
                    Volatile.Write(ref audiences, new Dictionary<Hero, CharacterAudience>());
                    if (!audienceErrorLogged) Diagnostics.Log("Character audience refresh unavailable: " + e.GetType().Name);
                    audienceErrorLogged = true;
                }
            }
            dirty = false;
        }
        private void RefreshWars()
        {
            warRefreshSeconds = 0;
            warsDirty = false;
            WarSnapshot currentWars = null;
            try
            {
                if (Diagnostics.Settings.IncludeWarBriefing) currentWars = WarReader.Read(Diagnostics.Settings);
                warReadErrorLogged = false;
            }
            catch (Exception e)
            {
                // Never retain stale scores after a failed read or block existing news.
                if (!warReadErrorLogged) Diagnostics.Log("War briefing unavailable; news capture continues: " + e);
                warReadErrorLogged = true;
            }
            try { warTrends.Observe(currentWars, Diagnostics.Settings); }
            catch (Exception e)
            {
                warTrends.Load("");
                if (currentWars != null) foreach (var war in currentWars.Wars) war.Trend = null;
                Diagnostics.Log("War trend update unavailable; current war briefing remains available: " + e.GetType().Name);
            }
            journal.UpdateWars(currentWars);
            Volatile.Write(ref publishedContext, journal.BuildContext());
            string status = currentWars == null ? "disabled/unavailable" : "active kingdom wars=" + currentWars.Wars.Count + "; stored clan assessments=" + currentWars.Clans.Count;
            if (status != lastWarStatus)
            {
                Diagnostics.Log("War briefing: " + status);
                lastWarStatus = status;
            }
            Diagnostics.WriteWarBriefing(currentWars == null ? "War briefing disabled or unavailable; see bridge.log." :
                WarKnowledge.Render(currentWars, null, Diagnostics.Settings, Diagnostics.Settings.WarBriefingMaxCharacters));
        }
        internal void Record(string key, string kind, string text, bool major)
        {
            if (!ready || Campaign.Current == null) return;
            double day = CampaignTime.Now.ToDays;
            if (!journal.Add(key, day, kind, text, major)) return;
            Diagnostics.Log("Captured " + kind + " at campaign day " + day.ToString("F2", CultureInfo.InvariantCulture) + ": " + Journal.Clean(text));
            Diagnostics.WriteCapturedReports(journal.Save());
            // Publish immediately with the previous snapshot; refresh snapshot on next tick.
            Volatile.Write(ref publishedContext, journal.BuildContext());
            dirty = true;
        }
        internal void QueueDirectNotification(string text)
        { if (ready) directNotifications.Enqueue(text); }
        internal static string Hash(string text)
        {
            using (var hash = SHA256.Create()) return BitConverter.ToString(hash.ComputeHash(Encoding.UTF8.GetBytes(text))).Replace("-", "");
        }
        internal void OnInjected(string context)
        {
            int count = Interlocked.Increment(ref injections);
            Diagnostics.Log("Injected Bellum context into dynamic-event prompt #" + count + "; characters=" + context.Length);
            Diagnostics.WriteContext(context);
            if (Diagnostics.Settings.ShowInjectionMessages) notices.Dynamic();
        }
        internal string CharacterContext(Hero hero, out string name)
        {
            name = "";
            if (!ready || !Diagnostics.Settings.EnableCharacterKnowledge || hero == null) return "";
            var cache = Volatile.Read(ref audiences);
            if (!cache.TryGetValue(hero, out var audience)) return "";
            name = audience.Name + " (" + audience.HeroId + ")";
            return journal.BuildCharacterContext(audience);
        }
        internal void OnCharacterInjected(string context, string name)
        {
            int count = Interlocked.Increment(ref characterInjections);
            Diagnostics.Log("Injected Bellum knowledge into character prompt #" + count + "; character=" + name + "; characters=" + context.Length);
            Diagnostics.WriteCharacterContext(context);
            if (Diagnostics.Settings.ShowInjectionMessages) notices.Character();
        }
        internal void FlushNotices()
        {
            if (!ready) { notices.Clear(); return; }
            foreach (var message in notices.Drain()) InformationManager.DisplayMessage(new InformationMessage(message));
        }
        internal void Stop()
        {
            ready = false;
            Volatile.Write(ref publishedContext, "");
            Volatile.Write(ref audiences, new Dictionary<Hero, CharacterAudience>());
            notices.Clear();
            while (directNotifications.TryDequeue(out _)) { }
        }
    }
}
