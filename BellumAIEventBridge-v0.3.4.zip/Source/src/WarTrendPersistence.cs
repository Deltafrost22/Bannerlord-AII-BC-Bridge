using System;

namespace BellumAIEventBridge
{
    // Reuse the tested 0.2.3 byte-bounded transport, with an independent keyspace.
    // Existing report keys and wire format remain exactly as in 0.2.3.
    internal static class WarTrendPersistence
    {
        internal const string LegacyKey = "BellumAIEventBridge_WarTrends_v1";
        internal const string ManifestKey = "BellumAIEventBridge_WarTrends_v2";
        internal static string ChunkKey(int index)
        { return Map(JournalPersistence.ChunkKey(index)); }

        private static string Map(string key)
        {
            if (key == JournalPersistence.LegacyKey) return LegacyKey;
            if (key.StartsWith(JournalPersistence.ManifestKey, StringComparison.Ordinal))
                return ManifestKey + key.Substring(JournalPersistence.ManifestKey.Length);
            throw new ArgumentException("Unexpected persistence key.", nameof(key));
        }
        private static SyncJournalString Adapt(SyncJournalString sync)
        { return (string key, ref string value) => sync(Map(key), ref value); }

        internal static void Save(SyncJournalString sync, string json)
        { JournalPersistence.Save(Adapt(sync), json); }
        internal static string Load(SyncJournalString sync)
        { return JournalPersistence.Load(Adapt(sync)); }
    }
}
