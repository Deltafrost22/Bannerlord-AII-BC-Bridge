using System;
using System.Linq;
using BellumAIEventBridge;
using Newtonsoft.Json;

internal static class CasualtyRemovalTests
{
    static void Check(bool ok, string message) { if (!ok) throw new Exception(message); }
    internal static void Run()
    {
        // An existing settings file must not reactivate removed count injection.
        var cfg = JsonConvert.DeserializeObject<BridgeSettings>("{\"IncludeWarCasualties\":true}");
        cfg.Normalize();
        var state = new WarSnapshot { Day = 107, PlayerKingdomId = "a" };
        var war = new WarState { Key = "a/b", FirstId = "a", SecondId = "b",
            FirstName = "Vlandia", SecondName = "Sturgia", StartedDay = 90,
            FirstScore = 45, FirstLosses = 17123123, SecondLosses = 28234234,
            Trend = new WarTrend { FromDay = 100, ToDay = 107,
                FirstScoreBefore = 10, FirstScoreNow = 45,
                FirstAdditionalLosses = 39345345, SecondAdditionalLosses = 40456456 } };
        state.Wars.Add(war);
        var journal = new Journal(cfg); journal.Update(107, ""); journal.UpdateWars(state);
        var a = new CharacterAudience { KingdomId = "a" };
        var b = new CharacterAudience { KingdomId = "b" };
        string[] outputs = {
            WarKnowledge.Render(state, null, cfg, 4000),
            WarKnowledge.Render(state, a, cfg, 4000), WarKnowledge.Render(state, b, cfg, 4000),
            WarTrends.Render(war, false, cfg, 1100), WarTrends.Render(war, true, cfg, 1100),
            journal.BuildContext(), journal.BuildCharacterContext(a), journal.BuildCharacterContext(b)
        };
        foreach (string text in outputs)
        {
            Check(!string.IsNullOrEmpty(text), "Empty briefing concealed a failed casualty test.");
            foreach (string forbidden in new[] { "17123123", "28234234", "39345345", "40456456",
                "45357357", "79801801", "casualt", "suffered", "inflicted", "death toll" })
                Check(text.IndexOf(forbidden, StringComparison.OrdinalIgnoreCase) < 0, "Removed casualty content leaked: " + forbidden);
        }
        Check(journal.BuildCharacterContext(a).Contains("Vlandia +45.0 (clearly winning)"), "Score analysis was removed.");
        Check(journal.BuildCharacterContext(b).Contains("Sturgia -45.0 (clearly losing)"), "Opponent score perspective lost.");
        Check(journal.BuildContext().Contains("+10.0 -> +45.0"), "Score trend was removed.");
        Check(WarKnowledge.Render(state, new CharacterAudience { KingdomId = "neutral" }, cfg, 4000) == "", "Own-kingdom scope changed.");

        // Old 0.3.3 trend JSON keeps its score history and remains readable.
        var legacy = new WarTrendStore(); legacy.Load(WarPersistenceTests.SmallHistory());
        string prior = legacy.Save();
        var wire = new PersistenceTests.Store(); WarTrendPersistence.Save(wire.Write, prior);
        var upgraded = new WarTrendStore(); upgraded.Load(WarTrendPersistence.Load(wire.Read));
        Check(upgraded.Save() == prior, "Legacy observations were destroyed during upgrade.");
        var current = new WarSnapshot { Day = 100.5 };
        current.Wars.Add(new WarState { Key = "a/b0", FirstId = "a", SecondId = "b0", StartedDay = 90,
            FirstName = "Vlandia", SecondName = "Sturgia", FirstScore = -30,
            FirstLosses = 17123123, SecondLosses = 28234234 });
        upgraded.Observe(current, cfg);
        var data = JsonConvert.DeserializeObject<WarTrendData>(upgraded.Save());
        Check(data.Wars.Single().Last.LossesA == null && data.Wars.Single().Last.LossesB == null, "New observations still collect casualty counts.");
        Check(current.Wars[0].Trend.FirstScoreBefore == -40 && current.Wars[0].Trend.FirstScoreNow == -30, "Legacy score baseline lost.");
        Check(current.Wars[0].Trend.FirstAdditionalLosses == null && current.Wars[0].Trend.SecondAdditionalLosses == null, "Legacy counts produced new casualty deltas.");
        Console.WriteLine("PASS: casualty removal from both sides, global/character prompts and trend renderers; old enabled setting ignored; legacy trend upgrade retains score history without new casualty observations/deltas.");
    }
}
