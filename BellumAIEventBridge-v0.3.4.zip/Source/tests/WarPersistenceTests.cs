using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using BellumAIEventBridge;
using Newtonsoft.Json;

internal static class WarPersistenceTests
{
    static int assertions;
    static void Check(bool ok, string why) { assertions++; if (!ok) throw new Exception(why); }
    static void Reject(Action action)
    {
        try { action(); } catch (InvalidDataException) { assertions++; return; }
        throw new Exception("Damaged trend transport was accepted.");
    }
    internal static string SmallHistory() => History(1, 1, 2);
    internal static string LargeHistory() => History(4, 80, 29);
    static string History(int wars, int holdings, int samples)
    {
        var data = new WarTrendData();
        for (int w = 0; w < wars; w++)
        {
            var h = new WarTrendHistory { Key = "a/b" + w, SideA = "a", SideB = "b" + w, StartedDay = 90 };
            for (int i = 0; i < samples; i++)
                h.Points.Add(new WarTrendPoint { Day = 100 + i * 0.25, Score = -40 + i,
                    LossesA = 100 + i * 20, LossesB = 200 + i * 30,
                    Holdings = Enumerable.Range(0, holdings).Select(n => new WarHolding {
                        Id = "town_" + n, Name = "Château 界 😀 " + n + " " + new string('x', 35),
                        OwnerId = n % 2 == 0 ? h.SideA : h.SideB }).ToList() });
            h.Last = h.Points.Last(); data.Wars.Add(h);
        }
        return JsonConvert.SerializeObject(data);
    }
    internal static void Run()
    {
        string large = LargeHistory();
        Check(Encoding.UTF8.GetByteCount(large) > 32763, "Stress fixture does not exceed old engine limit.");
        var store = new PersistenceTests.Store();
        string reports = File.ReadAllText(Path.Combine(AppContext.BaseDirectory, "fixtures/day635-crown-standard.json"));
        JournalPersistence.Save(store.Write, reports);
        var before = new Dictionary<string, string>(store.Values);
        WarTrendPersistence.Save(store.Write, large);
        Check(before.All(p => store.Values[p.Key] == p.Value), "Trend keys collided with report keys.");
        Check(store.Values[WarTrendPersistence.LegacyKey] == "", "Legacy unsafe trend writer returned.");
        Check(WarTrendPersistence.Load(store.Read) == large, "Trend payload was changed by chunking.");
        var parsed = new WarTrendStore(); parsed.Load(WarTrendPersistence.Load(store.Read));
        Check(parsed.Save() == large, "Trend observations/Unicode changed during load.");
        Check(JournalPersistence.Load(store.Read) == reports, "Reports changed after trend write.");

        var legacy = new PersistenceTests.Store(); legacy.Values[WarTrendPersistence.LegacyKey] = SmallHistory();
        string old = WarTrendPersistence.Load(legacy.Read);
        WarTrendPersistence.Save(legacy.Write, old);
        legacy.Values[WarTrendPersistence.LegacyKey] = "stale";
        Check(WarTrendPersistence.Load(legacy.Read) == old, "Old trend migration or v2 precedence failed.");
        Check(WarTrendPersistence.Load(new PersistenceTests.Store().Read) == "", "Absent trend key is not a fresh history.");

        var missing = store.Copy(); missing.Values.Remove(WarTrendPersistence.ChunkKey(1));
        Reject(() => WarTrendPersistence.Load(missing.Read));
        var changed = store.Copy(); changed.Values[WarTrendPersistence.ChunkKey(0)] = "X" + changed.Values[WarTrendPersistence.ChunkKey(0)].Substring(1);
        Reject(() => WarTrendPersistence.Load(changed.Read));
        var swapped = store.Copy(); string first = swapped.Values[WarTrendPersistence.ChunkKey(0)];
        swapped.Values[WarTrendPersistence.ChunkKey(0)] = swapped.Values[WarTrendPersistence.ChunkKey(1)];
        swapped.Values[WarTrendPersistence.ChunkKey(1)] = first;
        Reject(() => WarTrendPersistence.Load(swapped.Read));
        var unsupported = store.Copy(); unsupported.Values[WarTrendPersistence.ManifestKey] = "3|0|0|" + new string('0', 64);
        Reject(() => WarTrendPersistence.Load(unsupported.Read));
        var oversized = store.Copy(); oversized.Values[WarTrendPersistence.ChunkKey(0)] = new string('界', 24000);
        Reject(() => WarTrendPersistence.Load(oversized.Read));
        var failed = new PersistenceTests.Store { FailKey = WarTrendPersistence.ChunkKey(1) };
        Reject(() => WarTrendPersistence.Save(failed.Write, large));
        Check(!failed.Values.ContainsKey(WarTrendPersistence.ManifestKey), "Failed trend write committed manifest.");

        var empty = new WarTrendStore();
        WarTrendPersistence.Save(store.Write, empty.Save());
        Check(WarTrendPersistence.Load(store.Read) == empty.Save(), "Old chunks reappeared after history shrink.");
        for (int i = 0; i < 3; i++)
        {
            WarTrendPersistence.Save(store.Write, large);
            Check(WarTrendPersistence.Load(store.Read) == large, "Repeated large trend save failed.");
        }
        string retained = parsed.Save();
        Reject(() => parsed.Load("{\"Version\":99,\"Wars\":[]}"));
        Check(parsed.Save() == retained, "Unsupported schema erased in-memory trend history.");
        Console.WriteLine("PASS: war persistence: " + assertions + " checks; " + Encoding.UTF8.GetByteCount(large) +
            "-byte history, independent report/trend keys, legacy migration, corruption rejection, repeated saves, shrink and Unicode.");
    }
}
