// Engine-shaped doubles permit the ACTUAL BridgeBehavior.SyncData implementation
// to run in CI without launching Bannerlord. They do not replace live testing.
using System;
using System.Collections.Generic;
using System.IO;
using System.Reflection;
using BellumAIEventBridge;
using TaleWorlds.CampaignSystem;

namespace TaleWorlds.CampaignSystem
{
    public interface IDataStore
    { bool IsSaving { get; } bool IsLoading { get; } bool SyncData<T>(string key, ref T value); }
    public abstract class CampaignBehaviorBase
    { public abstract void RegisterEvents(); public abstract void SyncData(IDataStore store); }
    public sealed class Hero { }
    public sealed class CampaignGameStarter { }
    public sealed class SessionEvent { public void AddNonSerializedListener(object owner, Action<CampaignGameStarter> callback) { } }
    public sealed class Event1 { public void AddNonSerializedListener(object o, Action<object> a) { } }
    public sealed class Event3 { public void AddNonSerializedListener(object o, Action<object, object, object> a) { } }
    public sealed class Event5 { public void AddNonSerializedListener(object o, Action<object, object, object, object, object> a) { } }
    public sealed class Event6 { public void AddNonSerializedListener(object o, Action<object, object, object, object, object, object> a) { } }
    public static class CampaignEvents
    {
        public static SessionEvent OnSessionLaunchedEvent = new SessionEvent();
        public static Event1 MapEventEnded = new Event1();
        public static Event3 WarDeclared = new Event3(), MakePeace = new Event3();
        public static Event6 OnSettlementOwnerChangedEvent = new Event6();
        public static Event5 OnClanChangedKingdomEvent = new Event5();
    }
    public sealed class Campaign { public static Campaign Current = new Campaign(); }
    public struct CampaignTime { public static CampaignTime Now; public double ToDays => 52673.822806780096; }
}
namespace TaleWorlds.Library
{
    public sealed class InformationMessage { public InformationMessage(string value) { } }
    public static class InformationManager { public static void DisplayMessage(InformationMessage value) { } }
}
namespace BellumAIEventBridge
{
    internal static class Diagnostics
    {
        public static BridgeSettings Settings = new BridgeSettings();
        public static void Log(string s) { }
        public static void WriteContext(string s) { }
        public static void WriteCharacterContext(string s) { }
        public static void WriteCapturedReports(string s) { }
        public static void WriteWarBriefing(string s) { }
    }
    internal static class Hooks
    { public static bool SummaryReady = true, PromptReady = true, CharacterReady = true; public static void Install() { } }
    internal static class BellumReader
    {
        public static string Snapshot() => "";
        public static Dictionary<Hero, CharacterAudience> BuildAudiences() => new Dictionary<Hero, CharacterAudience>();
    }
    internal static class WarReader { public static WarSnapshot Read(BridgeSettings settings) => null; }
}
static class BehaviorPersistenceTests
{
    sealed class DataStore : IDataStore
    {
        internal PersistenceTests.Store Wire = new PersistenceTests.Store();
        public bool IsSaving { get; set; }
        public bool IsLoading => !IsSaving;
        public bool SyncData<T>(string key, ref T value)
        {
            if (typeof(T) != typeof(string)) throw new Exception("Unexpected persistence type.");
            string text = (string)(object)value;
            bool result = IsSaving ? Wire.Write(key, ref text) : Wire.Read(key, ref text);
            value = (T)(object)text; return result;
        }
    }
    static Journal JournalOf(BridgeBehavior behavior)
    { return (Journal)typeof(BridgeBehavior).GetField("journal", BindingFlags.Instance | BindingFlags.NonPublic).GetValue(behavior); }
    static WarTrendStore TrendsOf(BridgeBehavior behavior)
    { return (WarTrendStore)typeof(BridgeBehavior).GetField("warTrends", BindingFlags.Instance | BindingFlags.NonPublic).GetValue(behavior); }
    static void Check(bool value, string message) { if (!value) throw new Exception(message); }
    static void Main()
    {
        string full = File.ReadAllText(Path.Combine(AppContext.BaseDirectory, "fixtures/day629-original.json"));
        string repaired = File.ReadAllText(Path.Combine(AppContext.BaseDirectory, "fixtures/day629-repaired.json"));
        var original = new BridgeBehavior(); JournalOf(original).Load(full);
        var saving = new DataStore { IsSaving = true }; original.SyncData(saving);
        var loaded = new BridgeBehavior(); saving.IsSaving = false; loaded.SyncData(saving);
        Check(JournalOf(loaded).Count == 106 && JournalOf(loaded).Save() == JournalOf(original).Save(), "Actual SyncData dropped reports.");
        var old = new DataStore(); old.Wire.Values[JournalPersistence.LegacyKey] = repaired;
        var migration = new BridgeBehavior(); migration.SyncData(old);
        Check(JournalOf(migration).Count == 63, "Repaired save migration failed in behavior.");
        old.IsSaving = true; migration.SyncData(old); old.IsSaving = false;
        var migrated = new BridgeBehavior(); migrated.SyncData(old);
        Check(JournalOf(migrated).Save() == JournalOf(migration).Save(), "Migrated behavior reload differs.");
        var empty = new BridgeBehavior(); empty.SyncData(new DataStore());
        Check(JournalOf(empty).Count == 0, "New campaign inherited reports.");
        saving.Wire.Values.Remove(JournalPersistence.ChunkKey(0));
        var broken = new BridgeBehavior();
        try { broken.SyncData(saving); throw new Exception("Missing chunk was swallowed."); } catch (InvalidDataException) { }
        saving.IsSaving = true; int before = saving.Wire.Writes;
        try { broken.SyncData(saving); throw new Exception("Failed load overwrote history."); } catch (InvalidDataException) { }
        Check(before == saving.Wire.Writes, "Faulted behavior mutated save data.");
        WarIntegration();
        Console.WriteLine("PASS: actual BridgeBehavior.SyncData with engine-shaped store: 106-report save/load, repaired legacy migration, campaign isolation, damaged-data rejection and overwrite prevention.");
    }
    static void WarIntegration()
    {
        // Exact two-chunk report payload extracted from the user's working 0.2.3 save.
        string crown = File.ReadAllText(Path.Combine(AppContext.BaseDirectory, "fixtures/day635-crown-standard.json"));
        var from023 = new DataStore();
        JournalPersistence.Save(from023.Wire.Write, crown);
        var upgraded = new BridgeBehavior(); upgraded.SyncData(from023);
        Check(JournalOf(upgraded).Count == 97, "0.2.3 report upgrade lost history.");
        Check(TrendsOf(upgraded).Save() == new WarTrendStore().Save(), "0.2.3 upgrade invented trend history.");
        string large = WarPersistenceTests.LargeHistory();
        TrendsOf(upgraded).Load(large);
        from023.IsSaving = true; upgraded.SyncData(from023);
        Check(from023.Wire.Values.ContainsKey(WarTrendPersistence.ChunkKey(1)), "Actual SyncData did not split large trends.");
        Check(from023.Wire.Values[WarTrendPersistence.LegacyKey] == "", "Actual SyncData dual-wrote old trend key.");
        from023.IsSaving = false;
        var restored = new BridgeBehavior(); restored.SyncData(from023);
        Check(JournalOf(restored).Save() == JournalOf(upgraded).Save(), "Combined save changed reports.");
        Check(TrendsOf(restored).Save() == TrendsOf(upgraded).Save(), "Combined save changed trends.");

        var legacy = new DataStore();
        legacy.Wire.Values[JournalPersistence.LegacyKey] = "[]";
        legacy.Wire.Values[WarTrendPersistence.LegacyKey] = WarPersistenceTests.SmallHistory();
        var from032 = new BridgeBehavior(); from032.SyncData(legacy);
        string expected = TrendsOf(from032).Save();
        legacy.IsSaving = true; from032.SyncData(legacy); legacy.IsSaving = false;
        var migrated = new BridgeBehavior(); migrated.SyncData(legacy);
        Check(TrendsOf(migrated).Save() == expected, "Legacy trend migration changed data.");

        // A corrupt trend must block saving the entire behavior, including reports.
        from023.Wire.Values.Remove(WarTrendPersistence.ChunkKey(1));
        var broken = new BridgeBehavior();
        try { broken.SyncData(from023); throw new Exception("Missing trend chunk was swallowed."); } catch (InvalidDataException) { }
        from023.IsSaving = true; int before = from023.Wire.Writes;
        try { broken.SyncData(from023); throw new Exception("Faulted trend load allowed resave."); } catch (InvalidDataException) { }
        Check(before == from023.Wire.Writes, "Trend fault mutated report or trend storage.");

        var unsupported = new DataStore();
        WarTrendPersistence.Save(unsupported.Wire.Write, "{\"Version\":99,\"Wars\":[]}");
        broken = new BridgeBehavior();
        try { broken.SyncData(unsupported); throw new Exception("Future trend schema erased history."); } catch (InvalidDataException) { }
        unsupported.IsSaving = true; before = unsupported.Wire.Writes;
        try { broken.SyncData(unsupported); throw new Exception("Future trend schema allowed overwrite."); } catch (InvalidDataException) { }
        Check(before == unsupported.Wire.Writes, "Unsupported schema partially overwrote save.");
        Console.WriteLine("PASS: actual SyncData: working 0.2.3 two-chunk/97-report upgrade, simultaneous large trends, legacy 0.3.x trend migration, missing trend chunk and future schema overwrite prevention.");
    }
}
