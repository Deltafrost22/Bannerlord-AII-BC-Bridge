using System;
using System.Collections.Generic;
using System.Linq;
using BellumAIEventBridge;
using Newtonsoft.Json;

internal static class WarTrendTests
{
    private static void Check(bool ok, string message) { if (!ok) throw new Exception(message); }
    private static WarSnapshot Frame(double day, double? score = -10, long? a = 100, long? b = 200, bool transfer = false, double start = 90, bool flip = false)
    {
        var s = new WarSnapshot { Day = day, PlayerKingdomId = "a" };
        s.Wars.Add(new WarState { Key = "a/b", FirstId = flip ? "b" : "a", FirstName = flip ? "Sturgia" : "Vlandia",
            SecondId = flip ? "a" : "b", SecondName = flip ? "Vlandia" : "Sturgia", StartedDay = start,
            HasBellumRecord = true, FirstScore = flip ? -score : score, FirstLosses = flip ? b : a, SecondLosses = flip ? a : b,
            Holdings = new List<WarHolding> { new WarHolding { Id = "town", Name = "Pravend", OwnerId = transfer ? "b" : "a" },
                new WarHolding { Id = "castle", Name = "Sargot Castle", OwnerId = transfer ? "a" : "b" } } });
        return s;
    }
    internal static void Run()
    {
        var cfg = new BridgeSettings(); cfg.Normalize();
        var store = new WarTrendStore(); var initial = Frame(100);
        store.Observe(initial, cfg);
        Check(initial.Wars[0].Trend == null, "Invented pre-install history.");
        Check(WarTrends.Render(initial.Wars[0], false, cfg, 1100).Contains("collecting comparable history"), "No warm-up status.");
        var early = Frame(100.1, -20, 200, 300); store.Observe(early, cfg);
        Check(early.Wars[0].Trend == null, "Comparison before minimum interval.");
        var current = Frame(107, -45, 400, 700, true); store.Observe(current, cfg);
        var trend = current.Wars[0].Trend;
        Check(trend.FromDay == 100 && trend.ToDay == 107 && trend.FirstScoreBefore == -10 && trend.FirstScoreNow == -45, "Seven-day score comparison wrong.");
        Check(trend.FirstAdditionalLosses == null && trend.SecondAdditionalLosses == null, "New casualty deltas were calculated.");
        Check(trend.FirstGains.SequenceEqual(new[] { "Sargot Castle" }) && trend.SecondGains.SequenceEqual(new[] { "Pravend" }), "Territory attribution wrong.");
        string own = WarTrends.Render(current.Wars[0], false, cfg, 1100), other = WarTrends.Render(current.Wars[0], true, cfg, 1100);
        Check(own.Contains("-10.0 -> -45.0 (-35.0 points; position worsened)"), "Own score trend wrong.");
        Check(other.Contains("+10.0 -> +45.0 (+35.0 points; position improved)"), "Defender trend wrong.");
        Check(!other.Contains("suffered") && !other.Contains("inflicted"), "Casualty trend leaked.");
        Check(own.Contains("Net changes only") && own.Contains("not a forecast or proof of cause"), "Trend inference safeguards missing.");
        Check(own.Contains("Sargot Castle now Vlandia") && own.Contains("Pravend now Sturgia"), "Named territorial context missing.");
        var j = new Journal(cfg); j.Update(107, ""); j.UpdateWars(current);
        j.Add("news", 107, "PublicReport", "NEWS: An unrelated policy proposal failed.", false);
        Check(j.BuildContext().Contains("OBSERVED WAR TREND") && j.BuildContext().Contains("NEWS"), "Dynamic trends/news coexistence failed.");
        Check(j.BuildCharacterContext(new CharacterAudience { KingdomId = "b" }).Contains("Sturgia score +10.0 -> +45.0"), "Character trend perspective wrong.");
        Check(!j.Save().Contains("FirstScoreBefore"), "Trends polluted news save schema.");

        // Scope is kingdom participation, not global rank, player affiliation, or relevance tags.
        var foreign = Frame(107, 90, 999, 888);
        foreign.Wars[0].Key = "c/d";
        foreign.Wars[0].FirstId = "c"; foreign.Wars[0].FirstName = "Aserai";
        foreign.Wars[0].SecondId = "d"; foreign.Wars[0].SecondName = "Khuzait";
        foreign.Wars[0].Trend = new WarTrend { FromDay = 100, ToDay = 107, FirstScoreBefore = 10, FirstScoreNow = 90,
            FirstAdditionalLosses = 777, SecondAdditionalLosses = 666 };
        current.Wars.Add(foreign.Wars[0]);
        current.PlayerKingdomId = "c";
        var local = new CharacterAudience { KingdomId = "a", RelevantKingdomIds = new[] { "c", "d" } };
        string scoped = j.BuildCharacterContext(local);
        Check(scoped.Contains("Vlandia score -10.0 -> -45.0") && !scoped.Contains("Aserai") && !scoped.Contains("Khuzait"), "Foreign war data leaked into a participant's briefing.");
        Check(scoped.Contains("1 of 1 wars involving your kingdom") && scoped.Contains("NEWS"), "Character footer exposed global war count or news was lost.");
        string global = WarKnowledge.Render(current, null, new BridgeSettings { WarBriefingMaxCharacters = 8000 }, 8000);
        Check(global.Contains("Aserai") && global.Contains("Vlandia") && global.Contains("+10.0 -> +90.0"), "Global dynamic war coverage changed.");
        var neutral = new CharacterAudience { KingdomId = "neutral", RelevantKingdomIds = new[] { "a", "c" } };
        Check(!j.BuildCharacterContext(neutral).Contains("CURRENT WAR BRIEFING") && j.BuildCharacterContext(neutral).Contains("NEWS"), "Neutral kingdom received detailed war data or lost political news.");
        Check(WarKnowledge.Render(current, new CharacterAudience(), cfg, 4000) == "", "Missing kingdom fell back to global coverage.");
        local.KingdomId = "c";
        string changed = j.BuildCharacterContext(local);
        Check(changed.Contains("Aserai") && !changed.Contains("Vlandia"), "Changing kingdom retained old war access.");
        foreign.Wars[0].SecondId = "a"; foreign.Wars[0].SecondName = "Vlandia";
        string twoOwn = WarKnowledge.Render(current, new CharacterAudience { KingdomId = "a" }, new BridgeSettings { WarBriefingMaxCharacters = 8000 }, 8000);
        Check(twoOwn.Contains("2 of 2 wars involving your kingdom") && twoOwn.Contains("Aserai") && twoOwn.Contains("Sturgia"), "Multiple wars of the same kingdom were excluded.");
        current.Wars.RemoveAt(1); current.PlayerKingdomId = "a";

        // Persisted plain-data history, no mutation when a live snapshot is changed later.
        string saved = store.Save(); var restored = new WarTrendStore(); restored.Load(saved);
        var later = Frame(107, -40, 450, 750, true); restored.Observe(later, cfg);
        Check(later.Wars[0].Trend.FirstScoreBefore == -10 && later.Wars[0].Trend.FirstScoreNow == -40, "Save/load discarded history.");
        initial.Wars[0].Holdings[0].OwnerId = "b";
        var unchanged = Frame(107, -40, 450, 750, true); restored.Observe(unchanged, cfg);
        Check(unchanged.Wars[0].Trend.SecondGains.Contains("Pravend"), "Stored holdings alias live snapshot.");
        Check(trend.FirstScoreNow == -45, "Published trend was mutated by later refresh.");

        // BC can acquire a tracker after the vanilla war begins and reverse enumeration order.
        restored.Load(saved); var swapped = Frame(107, -45, 400, 700, true, flip: true); restored.Observe(swapped, cfg);
        Check(swapped.Wars[0].Trend.FirstScoreBefore == 10 && swapped.Wars[0].Trend.FirstScoreNow == 45 &&
            swapped.Wars[0].Trend.FirstAdditionalLosses == null, "First-side reorder changed real trend.");
        Check(WarTrends.Render(swapped.Wars[0], true, cfg, 1100).Contains("Vlandia score -10.0 -> -45.0"), "Double reversal wrong.");

        restored.Load(saved); var rollback = Frame(101, -15, 150, 250); restored.Observe(rollback, cfg);
        Check(rollback.Wars[0].Trend == null, "Future history survived campaign rollback.");
        restored.Load(saved); var reset = Frame(107.5, -45, 1, 2); restored.Observe(reset, cfg);
        Check(reset.Wars[0].Trend != null, "Unused casualty counters reset score history.");
        restored.Load(saved); var newWar = Frame(107.5, 0, 0, 0, start: 107.1); restored.Observe(newWar, cfg);
        Check(newWar.Wars[0].Trend == null, "Previous war history leaked into new war.");
        restored.Load(saved); restored.Observe(new WarSnapshot { Day = 107.1 }, cfg); restored.Observe(Frame(107.2), cfg);
        Check(JsonConvert.DeserializeObject<WarTrendData>(restored.Save()).Wars.Single().Points.Count == 1, "Peace did not clear old tracking.");
        restored.Load(saved); restored.Observe(null, cfg); var recovered = Frame(107, -45, 400, 700, true); restored.Observe(recovered, cfg);
        Check(recovered.Wars[0].Trend != null, "Temporary read failure erased valid history.");
        restored.Load(""); var fresh = Frame(107, -45, 400, 700); restored.Observe(fresh, cfg);
        Check(fresh.Wars[0].Trend == null, "Old save without trend data leaked another campaign's history.");

        // Actual interval remains honest for partial history and irregular observations.
        store = new WarTrendStore(); store.Observe(Frame(100), cfg); var partial = Frame(102, -12, 120, 230); store.Observe(partial, cfg);
        Check(WarTrends.Render(partial.Wars[0], false, cfg, 1100).Contains("2.00 days; target window 7 days"), "Partial history claims a full week.");
        var gap = Frame(110, -15, 160, 280); store.Observe(gap, cfg);
        Check(gap.Wars[0].Trend == null, "Comparison exceeded rolling window.");
        store = new WarTrendStore();
        WarSnapshot end = null;
        for (int i = 0; i <= 160; i++) { end = Frame(100 + i * .25, -10 - i * .1, 100 + i, 200 + i); store.Observe(end, cfg); }
        var data = JsonConvert.DeserializeObject<WarTrendData>(store.Save());
        Check(data.Wars.Single().Points.Count <= 29 && end.Wars[0].Trend.FromDay >= end.Day - 7, "History unbounded or too old.");
        store.Observe(Frame(140.001, -26, 260, 360), cfg);
        Check(JsonConvert.DeserializeObject<WarTrendData>(store.Save()).Wars.Single().Points.Count <= 29, "Realtime ticks bloated sampling.");

        // Unavailable is not zero. Neither enemy totals nor score imply an exact death toll.
        store = new WarTrendStore(); store.Observe(Frame(100, null, null, null), cfg);
        var unknown = Frame(101, null, null, null); unknown.Wars[0].Holdings = null; store.Observe(unknown, cfg);
        string absent = WarTrends.Render(unknown.Wars[0], false, cfg, 1100);
        Check(absent.Contains("score history unavailable") && absent.Contains("territorial observations unavailable"), "Missing metrics fabricated values.");
        var acquired = Frame(102); store.Observe(acquired, cfg);
        Check(acquired.Wars[0].Trend == null, "Missing score baseline treated as zero.");
        var enough = Frame(102.5, -8, 150, 250); store.Observe(enough, cfg);
        Check(enough.Wars[0].Trend.FromDay == 102, "Fresh comparable observations were ignored.");
        store = new WarTrendStore(); store.Observe(Frame(100), cfg); var recaptured = Frame(107); store.Observe(recaptured, cfg);
        Check(recaptured.Wars[0].Trend.FirstGains.Length == 0 && recaptured.Wars[0].Trend.SecondGains.Length == 0, "Unobserved recapture invented.");

        Check(!WarTrends.Render(current.Wars[0], false, cfg, 1100).Contains("Additional vanilla casualties"), "Removed casualty output returned.");
        cfg.IncludeWarTrends = false;
        Check(WarTrends.Render(current.Wars[0], false, cfg, 1100) == "", "Trend setting ignored.");
        store.Observe(current, cfg);
        Check(JsonConvert.DeserializeObject<WarTrendData>(store.Save()).Wars.Count == 0 && current.Wars[0].Trend == null, "Disabled tracking retained stale history.");
        cfg = new BridgeSettings { WarTrendDays = 99 }; cfg.Normalize(); Check(cfg.WarTrendDays == 30, "Upper window clamp missing.");
        cfg.WarTrendDays = -1; cfg.Normalize(); Check(cfg.WarTrendDays == 1, "Lower window clamp missing.");
        Check(JsonConvert.DeserializeObject<BridgeSettings>("{}").IncludeWarTrends, "Old settings did not enable trends by default.");
        current.Wars[0].Trend = trend;
        for (int budget = 0; budget <= 1200; budget += 37)
        {
            var text = WarTrends.Render(current.Wars[0], false, cfg, budget);
            Check(text.Length <= budget && (text.Length == 0 || text.EndsWith(".")), "Trend line/budget truncated.");
        }
        foreach (int budget in new[] { 2000, 5000, 10000, 12000 })
        {
            var limits = new BridgeSettings { MaxPromptCharacters = budget, CharacterMaxPromptCharacters = budget }; limits.Normalize();
            var journal = new Journal(limits); journal.Update(107, new string('f', 2500)); journal.UpdateWars(current);
            for (int n = 0; n < 25; n++) journal.Add("r" + n, 107, "PublicReport", "NEWS " + n + new string('x', 1200), false);
            var speaker = new CharacterAudience { KingdomId = "a", OwnFactionFacts = new string('c', 2500) };
            string dynamic = journal.BuildContext(), character = journal.BuildCharacterContext(speaker);
            Check(dynamic.Length <= limits.MaxPromptCharacters && character.Length <= limits.CharacterMaxPromptCharacters, "Trends overflowed shared prompt budgets.");
            if (budget >= 5000) Check(dynamic.Contains("OBSERVED WAR TREND") && character.Contains("OBSERVED WAR TREND") && dynamic.Contains("NEWS") && character.Contains("NEWS"), "Trends crowded out news or were omitted at normal budget.");
        }
        Console.WriteLine("PASS: war trends: warm-up, rolling/partial windows, saved history, rollback, peace/new-war/reset isolation, perspective changes, observed territory, missing data, sampling bounds, both prompt budgets, strict character kingdom scope and preserved global event coverage.");
    }
}
