using System;
using System.Collections.Generic;
using System.Linq;
using BellumAIEventBridge;

internal static class WarTests
{
    private static void Check(bool value, string message) { if (!value) throw new Exception(message); }
    private static WarSnapshot Fixture()
    {
        var s = new WarSnapshot { Day = 101, PlayerKingdomId = "vlandia" };
        s.Wars.Add(new WarState { Key = "s/v", FirstId = "vlandia", FirstName = "Vlandia", SecondId = "sturgia", SecondName = "Sturgia",
            FirstRulingClanId = "dey", SecondRulingClanId = "vag", StartedDay = 90, HasBellumRecord = true, ConflictType = "ForeignWar",
            FirstScore = 63.5, FirstLosses = 1234, SecondLosses = 5678,
            Components = new Dictionary<string, double> { ["battle advantage"] = 30, ["prisoner leverage"] = -10, ["territorial control"] = 43.5 } });
        s.Clans["dey"] = new WarClanAssessment { ClanId = "dey", ClanName = "dey Meroc", KingdomId = "vlandia", WarWill = 80,
            TargetReasons = new Dictionary<string, string[]> { ["sturgia"] = new[] { "strong claim: Nevyansk", "poor relations with target ruler" } },
            Pressures = new Dictionary<string, string[]> { ["sturgia"] = new[] { "own village raided (war-will effect +8.0)" } } };
        s.Clans["vag"] = new WarClanAssessment { ClanId = "vag", ClanName = "Vagiroving", KingdomId = "sturgia", WarWill = 15,
            Pressures = new Dictionary<string, string[]> { ["vlandia"] = new[] { "own town lost (war-will effect -20.0)" } } };
        return s;
    }
    internal static void Run()
    {
        var cfg = new BridgeSettings(); cfg.Normalize();
        var s = Fixture();
        var ally = new CharacterAudience { Name = "Ally", KingdomId = "vlandia", ClanId = "dey" };
        var enemy = new CharacterAudience { Name = "Enemy", KingdomId = "sturgia", ClanId = "vag" };
        string a = WarKnowledge.Render(s, ally, cfg, 4000), b = WarKnowledge.Render(s, enemy, cfg, 4000);
        Check(a.Contains("Vlandia +63.5 (clearly winning)") && b.Contains("Sturgia -63.5 (clearly losing)"), "Score perspective inverted.");
        Check(b.Contains("defending against Vlandia") && a.Contains("attacking Sturgia"), "Attacker/defender labels wrong.");
        Check(b.Contains("territorial control -43.5") && b.Contains("prisoner leverage +10.0"), "Component perspective wrong.");
        Check(a.Contains("Your clan dey Meroc") && a.Contains("strong claim: Nevyansk") && a.Contains("own village raided"), "Own-clan reasons missing.");
        Check(b.Contains("Your clan Vagiroving") && b.Contains("inclined toward peace"), "Enemy clan stance not preserved.");
        Check(a.Contains("not proven original war causes"), "Current assessments masquerade as historical causes.");
        foreach (var score in new[] { -100.0, -99, -75, -74, -40, -39, -10, -9, 0, 9, 10, 39, 40, 74, 75, 99, 100 })
        {
            s.Wars[0].FirstScore = score;
            string text = WarKnowledge.Render(s, ally, cfg, 4000);
            Check(text.Contains(WarKnowledge.Standing(score)) && text.Contains(WarKnowledge.Standing(-score)), "Score band mismatch.");
            Check(text.Contains("NOT proof peace or surrender has completed"), "Premature surrender instruction.");
        }
        s.Wars[0].Resolution = "forced peace talks pending; no completed treaty established";
        Check(WarKnowledge.Render(s, ally, cfg, 4000).Contains("forced peace talks pending"), "Pending resolution omitted.");
        s.Wars[0].FirstLosses = int.MaxValue; s.Wars[0].SecondLosses = int.MaxValue;
        cfg.IncludeWarMotivations = false;
        Check(!WarKnowledge.Render(s, ally, cfg, 4000).Contains("war will"), "Motive setting ignored.");
        cfg.IncludeWarBriefing = false;
        Check(WarKnowledge.Render(s, ally, cfg, 4000) == "", "Master briefing setting ignored.");
        cfg = new BridgeSettings(); cfg.Normalize(); s = Fixture();
        s.Wars[0].FirstScore = null; s.Wars[0].HasBellumRecord = false; s.Wars[0].FirstLosses = null;
        string unknown = WarKnowledge.Render(s, ally, cfg, 4000);
        Check(unknown.Contains("BC score unavailable"), "Unknown data invented a zero.");
        Check(unknown.Contains("at war with") && !unknown.Contains("attacking Sturgia"), "Vanilla ordering invented an attacker.");

        s = Fixture();
        // Characters see only their own realm's wars; global generation still prioritizes player wars.
        s.Wars.Insert(0, new WarState { Key = "foreign", FirstId = "empire", FirstName = "Empire", SecondId = "battania", SecondName = "Battania", FirstScore = 99, FirstLosses = 1, SecondLosses = 2 });
        s.Wars.Add(new WarState { Key = "own", FirstId = "aserai", FirstName = "Aserai", SecondId = "khuzait", SecondName = "Khuzait", FirstScore = 1, FirstLosses = 3, SecondLosses = 4 });
        var foreignSpeaker = new CharacterAudience { KingdomId = "aserai" };
        cfg.WarBriefingMaxWars = 1;
        Check(WarKnowledge.Render(s, foreignSpeaker, cfg, 4000).Contains("Aserai (kingdom_id=aserai)"), "Own war did not win priority.");
        Check(!WarKnowledge.Render(s, foreignSpeaker, cfg, 4000).Contains("Vlandia (kingdom_id=vlandia)"), "War count limit ignored.");
        Check(WarKnowledge.Render(s, null, cfg, 4000).Contains("Vlandia (kingdom_id=vlandia)"), "Dynamic briefing should prioritize player war.");
        cfg.WarBriefingMaxWars = 6;
        foreach (int budget in new[] { 600, 700, 1000, 1800, 4000, 8000 })
        {
            string text = WarKnowledge.Render(s, ally, cfg, budget);
            Check(text.Length <= budget, "War budget exceeded.");
            if (text.Contains("Vlandia (kingdom_id=vlandia)")) Check(text.Contains("Vlandia +63.5 (clearly winning)"), "Mandatory score line cut or lost.");
        }
        foreach (int budget in new[] { 2000, 5000, 10000, 12000 })
        {
            var limits = new BridgeSettings { MaxPromptCharacters = budget, CharacterMaxPromptCharacters = budget };
            limits.Normalize(); var j = new Journal(limits);
            for (int i = 0; i < 50; i++) j.Add("r" + i, 101, "PublicReport", "NEWS " + i + new string('x', 1300), false);
            j.Update(101, string.Join("\n", Enumerable.Repeat(new string('f', 300), 20)));
            j.UpdateWars(s);
            ally.OwnFactionFacts = string.Join("\n", Enumerable.Repeat(new string('c', 300), 10));
            ally.LocalFactionFacts = string.Join("\n", Enumerable.Repeat(new string('l', 300), 10));
            Check(j.BuildContext().Length <= limits.MaxPromptCharacters, "War+news dynamic budget exceeded.");
            Check(j.BuildCharacterContext(ally).Length <= limits.CharacterMaxPromptCharacters, "War+news dialogue budget exceeded.");
            if (budget >= 5000)
            {
                Check(j.BuildContext().Contains("CURRENT WAR BRIEFING") && j.BuildContext().Contains("NEWS"), "Dynamic war/news coexistence failed.");
                Check(j.BuildCharacterContext(ally).Contains("CURRENT WAR BRIEFING") && j.BuildCharacterContext(ally).Contains("NEWS"), "Dialogue war/news coexistence failed.");
            }
        }
        var journal = new Journal(cfg); journal.Update(101, ""); journal.UpdateWars(Fixture());
        Check(journal.BuildContext().Contains("CURRENT WAR BRIEFING"), "Wars alone should yield dynamic context.");
        Check(journal.BuildCharacterContext(new CharacterAudience { KingdomId = "vlandia" }).Contains("CURRENT WAR BRIEFING"), "Own wars alone should yield character context.");
        Check(journal.BuildCharacterContext(new CharacterAudience()) == "", "Unaffiliated character received a foreign war briefing.");
        Check(journal.Save() == "[]", "Current war snapshots polluted retained news.");
        journal.UpdateWars(new WarSnapshot { Day = 102 });
        Check(journal.BuildContext() == "" && journal.BuildCharacterContext(new CharacterAudience()) == "", "Ended wars persisted in snapshot.");
        journal.UpdateWars(Fixture()); journal.Load("[]");
        Check(journal.BuildContext() == "", "War state leaked across save load.");
        journal.UpdateWars(Fixture()); journal.UpdateWars(null);
        Check(journal.BuildContext() == "", "Failed refresh retained old war data.");
        Console.WriteLine("PASS: war score/component perspective, current motives, pending resolutions, priority, settings, whole-line limits, prompt budgets, snapshot expiry/isolation and unchanged news persistence.");
    }
}
