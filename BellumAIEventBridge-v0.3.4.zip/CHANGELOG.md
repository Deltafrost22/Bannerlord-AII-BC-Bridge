# 0.3.4

- Removed vanilla casualty-counter reads and all structured war-total/casualty-delta output from character and dynamic-event briefings.
- Removed the IncludeWarCasualties setting; existing true values are ignored.
- New trend observations do not collect casualty counts, and score baselines no longer depend on casualty-counter changes.
- Retained war scores, score trends, existing non-casualty war context, own-kingdom character filtering and political news.
- Preserved chunked report/trend persistence and readable legacy history; no save-format change or campaign reset.
- Added regression coverage for all briefing routes, enabled legacy settings and old trend histories containing casualty values.

Existing AI Influence conversation memories and ordinary Bellum political report text are not erased or rewritten.
