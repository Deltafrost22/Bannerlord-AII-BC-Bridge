param([string]$GamePath = 'F:\SteamLibrary\steamapps\common\Mount & Blade II Bannerlord')
$ErrorActionPreference = 'Stop'
$gameBin = Join-Path $GamePath 'bin\Win64_Shipping_Client'
if (-not (Test-Path (Join-Path $gameBin 'TaleWorlds.CampaignSystem.dll'))) {
    throw "Game assemblies were not found in $gameBin"
}
Push-Location $PSScriptRoot
try {
    & dotnet build '.\Bridge.csproj' -c Release "-p:GameBin=$gameBin"
    if ($LASTEXITCODE -ne 0) { throw 'Bridge build failed.' }
    & dotnet run --project '.\tests\JournalTests.csproj' -c Release "-p:GameBin=$gameBin"
    if ($LASTEXITCODE -ne 0) { throw 'Core tests failed.' }
    $module = Join-Path $PSScriptRoot 'dist\Modules\BellumAIEventBridge'
    $binary = Join-Path $module 'bin\Win64_Shipping_Client'
    New-Item -ItemType Directory -Path $binary -Force | Out-Null
    Copy-Item '.\SubModule.xml' $module -Force
    Copy-Item '.\bin\Release\net472\BellumAIEventBridge.dll' $binary -Force
    Write-Host "Built module: $module"
} finally { Pop-Location }
