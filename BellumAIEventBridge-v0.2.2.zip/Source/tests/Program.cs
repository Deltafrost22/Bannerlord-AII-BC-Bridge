using System;
using System.Linq;
using System.Threading.Tasks;
using BellumAIEventBridge;

static class Program
{
    static int assertions;
    static void Check(bool condition, string message)
    { System.Threading.Interlocked.Increment(ref assertions); if (!condition) throw new Exception(message); }
    static void Main()
    {
        var settings = new BridgeSettings(); settings.Normalize();
        var journal = new Journal(settings);
        Check(journal.BuildContext() == "", "An empty journal must add no prompt text.");
        Check(journal.Add("war-1", 100, "CivilWarStarted", "A rebellion began.", true), "Initial event missing.");
        Check(!journal.Add("war-1", 100.1, "CivilWarStarted", "A repeated report.", true), "Structured event duplicated.");
        Check(!journal.Add("war-2", 100.2, "PublicReport", "A rebellion began.", false), "Identical report duplicated.");
        string saved = journal.Save();
        var restored = new Journal(settings); restored.Load(saved); restored.Update(100.5, "");
        Check(restored.Count == 1 && restored.BuildContext().Contains("A rebellion began."), "History failed to round-trip.");
        Check(!restored.Add("war-1", 100.5, "CivilWarStarted", "Duplicate after loading", true), "Dedup lost after load.");
        restored.Update(131, "");
        Check(restored.Count == 0 && restored.BuildContext() == "", "Expired evidence leaked into prompt.");
        restored.Load(saved); restored.Update(99, "");
        Check(restored.Count == 0, "Future reports leaked into an earlier timeline.");
        var otherCampaign = new Journal(settings);
        Check(otherCampaign.Count == 0, "Campaign histories are not isolated.");

        Check(Journal.Clean("{=KEY}<b>Report</b>\r\n next") == "Report next", "Markup cleaning failed.");
        Check(Journal.Clean(new string('x', 1500)).Length == 1400, "Report size limit failed.");
        Check(!journal.Add("nan", double.NaN, "invalid", "invalid", false), "Invalid campaign date accepted.");

        foreach (int budget in new[] { 2000, 10000, 24000 })
        {
            var cfg = new BridgeSettings { MaxPromptCharacters = budget, SnapshotMaxCharacters = 6000, MaxPromptEvents = 24 };
            cfg.Normalize(); var j = new Journal(cfg);
            for (int i = 0; i < 200; i++) j.Add("id-" + i, 100 + i * 0.001, "Report", "Report " + i + " " + new string('a', 1300), i % 3 == 0);
            j.Update(101, string.Join("\n", Enumerable.Range(0, 12).Select(i => "Faction " + i + new string('s', 600))));
            Check(j.Count == 160, "Storage bound failed.");
            var context = j.BuildContext();
            Check(context.Length <= budget, "Prompt character bound failed: " + context.Length + " > " + budget);
            Check(context.Contains("[END_BELLUM_CIVILE_OBSERVED_CONTEXT]"), "Context footer missing.");
            Check(context.Split('\n').Count(l => l.StartsWith("- Day ")) <= 24, "Event count bound failed.");
        }
        var off = new Journal(new BridgeSettings { Enabled = false });
        off.Add("x", 1, "test", "test", true);
        Check(off.BuildContext() == "", "Disabled bridge emits a prompt.");

        var concurrent = new Journal(settings);
        Parallel.For(0, 400, i =>
        {
            concurrent.Add("parallel-" + i, 100, "Concurrent", "Report " + i, false);
            concurrent.Update(100, "- Active faction snapshot.");
            Check(concurrent.BuildContext().Length <= settings.MaxPromptCharacters, "Concurrent prompt exceeded bound.");
            concurrent.Save();
        });
        Check(concurrent.Count <= settings.MaxStoredEvents, "Concurrent storage exceeded bound.");
        CharacterTests();
        BroadSharingTests();
        HookTests.Run();
        DynamicHookTests.Run();
        Console.WriteLine("PASS: persistence, campaign isolation, deduplication, expiry, rollback, sanitation, bounds, disabled mode, concurrency, character relevance/privacy, v0.1 migration, prompt-prefix preservation, and injection notices.");
    }
    static void CharacterTests()
    {
        var cfg = new BridgeSettings { ShareAllBellumUpdates = false }; cfg.Normalize();
        var j = new Journal(cfg);
        var audience = new CharacterAudience { HeroId = "lord_1", ClanId = "clan_1", KingdomId = "realm_1", Name = "Test lord" };
        j.Add("self", 100, "PublicReport", "SELF public clan report (clan_id=clan_1)", false);
        j.Add("local", 100, "PublicReport", "LOCAL report (kingdom_id=realm_1)", false);
        j.Add("foreign", 100, "PublicReport", "FOREIGN minor report (kingdom_id=realm_2)", false);
        j.Add("major", 100, "Outcome", "MAJOR foreign war (kingdom_id=realm_2)", true);
        j.Add("private", 100, "PersonalReport", "PRIVATE secret (hero_id=lord_1)", true);
        j.Update(100, "");
        string context = j.BuildCharacterContext(audience);
        Check(context.Contains("SELF") && context.Contains("LOCAL") && context.Contains("MAJOR"), "Relevant public reports missing.");
        Check(!context.Contains("FOREIGN minor") && !context.Contains("PRIVATE secret"), "Unrelated/private news leaked.");
        Check(context.IndexOf("SELF") < context.IndexOf("MAJOR"), "Personal relevance lost priority.");
        Check(j.BuildCharacterContext(new CharacterAudience { KingdomId = "realm_10" }).Contains("LOCAL report") == false, "Partial realm-ID match leaked local news.");
        var migration = new Journal(cfg);
        migration.Load("[{\"Key\":\"old\",\"Day\":100,\"Kind\":\"PublicReport\",\"Text\":\"OLD news (kingdom_id=realm_1)\",\"Major\":false}]");
        migration.Update(100, "");
        Check(migration.BuildCharacterContext(audience).Contains("OLD news"), "v0.1 history relevance migration failed.");
        var reload = new Journal(cfg); reload.Load(j.Save()); reload.Update(100, "");
        Check(reload.BuildCharacterContext(audience) == context, "Character relevance changed after saving/loading.");

        foreach (int budget in new[] { 2000, 5000, 12000 })
        {
            var limitedCfg = new BridgeSettings { CharacterMaxPromptCharacters = budget }; limitedCfg.Normalize();
            var limited = new Journal(limitedCfg);
            for (int i = 0; i < 50; i++) limited.Add("long-" + i, 100, "PublicReport", new string('x', 1400), true);
            var verbose = new CharacterAudience { Name = new string('n', 150), HeroId = new string('i', 150),
                OwnFactionFacts = string.Join("\n", Enumerable.Repeat(new string('f', 800), 5)),
                LocalFactionFacts = string.Join("\n", Enumerable.Repeat(new string('l', 800), 5)) };
            limited.Update(100, "");
            string text = limited.BuildCharacterContext(verbose);
            Check(text.Length > 0, "Low character budget silently dropped all available facts.");
            Check(text.Length <= budget, "Character context budget exceeded: " + text.Length + "/" + budget);
            if (text.Length > 0) Check(text.Contains("[END_BELLUM_CIVILE_CHARACTER_KNOWLEDGE]"), "Character footer truncated.");
        }
        var empty = new Journal(cfg);
        Check(empty.BuildCharacterContext(audience) == "", "Empty character context should not inject.");
        cfg.EnableCharacterKnowledge = false;
        Check(j.BuildCharacterContext(audience) == "", "Disabled character hook still supplies knowledge.");

        string prefix = "STATIC PREFIX", tail = "ORIGINAL HISTORY AND JSON FORMAT";
        string prompt = prefix + tail;
        Check(PromptAugmentation.TryInsertCharacterContext(ref prompt, prefix.Length, context), "Character insertion failed.");
        Check(prompt.Substring(0, prefix.Length) == prefix && prompt.EndsWith(tail), "Original prefix/tail was modified.");
        Check(prompt.IndexOf(CharacterKnowledge.Marker) >= prefix.Length, "Knowledge leaked into cached static prefix.");
        Check(!PromptAugmentation.TryInsertCharacterContext(ref prompt, prefix.Length, context), "Double injection allowed.");
        string deferred = prefix;
        Check(PromptAugmentation.TryInsertCharacterContext(ref deferred, prefix.Length, context) && deferred.StartsWith(prefix), "Deferred-history prompt insertion failed.");
        string invalid = "x";
        Check(!PromptAugmentation.TryInsertCharacterContext(ref invalid, 9, context) && invalid == "x", "Invalid boundary changed prompt.");

        var notices = new InjectionNotices();
        Check(notices.Drain().Length == 0, "Untriggered notice appeared.");
        Parallel.For(0, 100, i => { notices.Character(); notices.Dynamic(); });
        var messages = notices.Drain();
        Check(messages.SequenceEqual(new[] { "News is spreading amongst notables.", "News is spreading rapidly amongst the kingdom." }), "Notice text/coalescing failed.");
        Check(notices.Drain().Length == 0, "Notices repeated without injection.");
        notices.Character(); notices.Clear();
        Check(notices.Drain().Length == 0, "Previous campaign notice leaked.");
    }
    static void BroadSharingTests()
    {
        // Reproduce the user's old settings: omitted new field, personal=false.
        var cfg = Newtonsoft.Json.JsonConvert.DeserializeObject<BridgeSettings>("{\"Enabled\":true,\"EnableCharacterKnowledge\":true,\"IncludePersonalNotifications\":false}");
        cfg.Normalize();
        Check(cfg.ShareAllBellumUpdates && cfg.CaptureNotification(true) && cfg.CaptureNotification(false), "Upgrade must capture both notification flags without changing the old JSON.");
        var j = new Journal(cfg);
        var companion = new CharacterAudience { Name = "Companion", KingdomId = "vlandia" };
        j.Add("claim", 100, "PublicReport", "Awdhan investigates an Askar claim (kingdom_id=aserai)", false);
        j.Add("marshal", 100, "PersonalReport", "Culharn appointed marshal (kingdom_id=battania)", false);
        j.Add("reaction", 100, "PublicReport", "Populists celebrate; Aristocrats are displeased (kingdom_id=battania)", false);
        string context = j.BuildCharacterContext(companion);
        Check(context.Contains("Askar claim") && context.Contains("appointed marshal") && context.Contains("Aristocrats"), "Foreign routine/player-directed updates must reach a companion.");
        Check(context.Contains("Selected 3 reports; eligible=3; retained=3"), "Diagnostic counts must distinguish retention and selection.");
        Check(j.BuildContext().Contains("appointed marshal"), "Dynamic context must receive player-directed updates too.");
        var reload = new Journal(cfg); reload.Load(j.Save()); reload.Update(100, "");
        Check(reload.BuildCharacterContext(companion) == context, "Broad sharing/order changed after reload.");
        cfg.CharacterMaxPromptEvents = 1; cfg.MaxPromptEvents = 1;
        j.Add("major", 100, "Outcome", "OLD MAJOR REPORT", true);
        j.Add("latest", 100, "DirectNotification", "LATEST ORDINARY UPDATE", false);
        Check(j.BuildCharacterContext(companion).Contains("LATEST ORDINARY UPDATE") && !j.BuildCharacterContext(companion).Contains("OLD MAJOR REPORT"), "Newest arrival must win even with equal campaign timestamps.");
        Check(j.BuildContext().Contains("LATEST ORDINARY UPDATE") && !j.BuildContext().Contains("OLD MAJOR REPORT"), "Dynamic all-mode must not starve new ordinary updates.");
        cfg.MaxStoredEvents = 10;
        for (int i = 0; i < 15; i++) j.Add("same-day-" + i, 100, "PublicReport", "SAME DAY " + i, false);
        Check(j.Count == 10 && j.BuildCharacterContext(companion).Contains("SAME DAY 14"), "Storage pruning lost newest same-day reports.");
        cfg.ShareAllBellumUpdates = false;
        Check(!cfg.CaptureNotification(true) && cfg.CaptureNotification(false), "Selective mode must retain legacy capture switches.");
        cfg.Enabled = false;
        Check(!cfg.CaptureNotification(false) && !cfg.CaptureNotification(true), "Master disable must stop capture.");
        NotificationOriginTests();
        Console.WriteLine("PASS: broad sharing, foreign companion news, player-directed news, old settings upgrade, same-day newest-first selection/storage, and notification origin filtering.");
    }
    static void NotificationOriginTests()
    {
        var assembly = System.Reflection.Emit.AssemblyBuilder.DefineDynamicAssembly(new System.Reflection.AssemblyName("BellumCivile"), System.Reflection.Emit.AssemblyBuilderAccess.Run);
        var module = assembly.DefineDynamicModule("Fixture");
        System.Reflection.MethodBase Make(string name)
        {
            var type = module.DefineType(name, System.Reflection.TypeAttributes.Public);
            var method = type.DefineMethod("Notify", System.Reflection.MethodAttributes.Public | System.Reflection.MethodAttributes.Static, typeof(void), Type.EmptyTypes);
            method.GetILGenerator().Emit(System.Reflection.Emit.OpCodes.Ret);
            return type.CreateType().GetMethod("Notify");
        }
        var direct = Make("BellumCivile.Behaviors.ForeignTreatyBehavior");
        var shared = Make("BellumCivile.BellumCivileNotifications");
        var unrelated = typeof(Program).GetMethod("Main", System.Reflection.BindingFlags.Static | System.Reflection.BindingFlags.NonPublic);
        Check(NotificationOrigin.IsDirectBellum(new[] { unrelated, direct }), "Direct Bellum notification not recognized.");
        Check(!NotificationOrigin.IsDirectBellum(new[] { unrelated, shared, direct }), "Shared notification would be captured twice.");
        Check(!NotificationOrigin.IsDirectBellum(new[] { unrelated }), "Unrelated game/bridge notices must not become Bellum reports.");
        Check(!NotificationOrigin.IsDirectBellum(new System.Reflection.MethodBase[] { null }), "Missing frames must fail closed.");
    }
}
