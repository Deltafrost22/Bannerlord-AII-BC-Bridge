# Bellum AI Event Bridge 0.2.2

Supplies Bellum Civile reports to AI Influence character dialogue and dynamic-event prompts.

Target: Bannerlord **1.4.5**, the supplied Bellum Civile **1.2.7** and AI Influence **6.0.0**, with Bannerlord Harmony enabled. Compiled against the supplied game references. Automated tests pass; this update still needs in-game testing.

## Install or upgrade

1. Close Bannerlord.
2. Replace your existing `Modules\BellumAIEventBridge` folder with `Modules\BellumAIEventBridge` from this ZIP. Do not make a second bridge module or a `Modules\Modules` folder.
3. Keep the bridge enabled below Bellum Civile and AI Influence, with Harmony before the bridge.
4. Keep `Enabled` and `EnableCharacterKnowledge` set to `true` in your existing settings. No settings reset is needed. The new `ShareAllBellumUpdates` setting defaults to `true` when absent, even if your old file has `IncludePersonalNotifications: false`.
5. Restart Bannerlord and load your campaign. The ready message should show both integrations ON.

Only the module folder goes into the game. `Source` is optional source code, not an installation requirement. Existing saved bridge reports remain compatible.

## What changed

The previous character filter excluded routine foreign reports. It also treated Bellum's `isPersonal` flag as secrecy, although Bellum uses that flag for some public announcements concerning the player's kingdom.

Broad sharing is now on by default:

- Every retained report is eligible for every character, including companions, regardless of kingdom, importance or personal flag.
- Newest reports take priority in both character and dynamic-event contexts. The newest arrival wins when campaign timestamps are equal, including when the storage limit is reached.
- Shared Bellum notifications are captured regardless of their personal flag or the player's Bellum notification-display filter.
- A listener on the game's existing notification event additionally captures direct messages whose call stack comes from the BellumCivile assembly. This covers paths that bypass Bellum's shared notification method. Shared notifications are excluded from the listener to avoid duplicate capture; unrelated game and bridge messages are ignored.
- Logs now include captured report text. Character context shows selected, eligible and retained report counts.

Broad sharing includes player-directed/private game notifications. NPCs can consequently learn those supplied facts. Notification flags do not establish whether an incident is public. Direct messages can also be interface feedback; the prompt tells the AI that failed actions and proposals are not completed events.

The character and dynamic-event integration methods from 0.2.1 are preserved. The protected core prompt builder and `BuildFinalInstruction` remain unpatched.

## When knowledge updates

A shared Bellum notification or structured rebellion report enters the campaign journal when captured. Direct notification messages are queued and recorded on the next application tick. New reports then become eligible for the next normal character or dynamic-event prompt.

This does not make a separate AI request on each Bellum update, force a new dynamic event, or interrupt an AI request already in progress. The news blurbs appear when context is actually inserted:

- **News is spreading amongst notables.** — character prompt
- **News is spreading rapidly amongst the kingdom.** — dynamic-event prompt

A blurb proves insertion, not a successful AI response or a published event. Another conversation can show the blurb again while using retained news. Same-type injections within one frame share one blurb.

Knowledge is supplied in prompts, not written directly into AI Influence's permanent `KnownInfo` or NPC memory files. AI Influence controls any long-term memory resulting from conversation.

## Coverage and limits

Captured sources include four structured rebellion reports (formation, ultimatum, civil war and outcome), Bellum's shared string notification method (also used by its TextObject and personal overloads), and direct displayed notifications with an identifiable Bellum assembly stack frame. The optional current snapshot supplies rebel-faction state; character snapshots also supply their clan's affiliations.

This covers all notification types passing through these sources, not every invisible internal Bellum calculation. Reports from before installation, or previously skipped by capture settings, cannot be reconstructed. Previously retained foreign reports become eligible immediately after upgrading. The direct listener only sees messages actually dispatched and depends on identifiable stack frames; future parent-mod changes may require an update.

History and prompt size remain bounded. Defaults retain 160 reports for 30 campaign days and consider the newest 24 reports per prompt, within 10,000 characters for each bridge context. A busy campaign can exceed those limits; older reports may be omitted or expire before another prompt. Long report text can be shortened. No claim is made that every historical update fits into every prompt or that the model will mention every supplied fact.

The bridge supplies evidence to AI Influence's normal generator. It does not itself publish World Events or change wars, peace, transfers or diplomacy rules. The original prompt prefix, instructions, output schema, backend and returned task are preserved.

## Check that the fix works

Open your Windows Documents folder (including OneDrive's redirected Documents if applicable), then:

`Mount and Blade II Bannerlord\Configs\BellumAIEventBridge`

1. `bridge.log` should say **0.2.2 loaded**. Hook status should show `dynamic-event prompt=True`, `character prompt=True`, `rebellion reports=4/4`, `public notifications=True`, `direct notification listener=True`, and `ShareAllBellumUpdates=True`.
2. After a Bellum announcement, look for its words in a `Captured ...` log entry and `last-captured-reports.json`. This JSON is a diagnostic copy of retained journal data; do not edit it to add reports.
3. Talk to your companion. Look for the notables blurb and open `last-character-context.txt`. Recent captured news should appear under REPORTS YOU CAN DRAW ON. The footer now says, for example, `Selected 3 reports; eligible=3; retained=3; sharing=all Bellum updates`.
4. Let AI Influence run its normal dynamic-event cycle. Look for the kingdom blurb and the report in `last-injected-context.txt`. The log records the request handoff and eventual request completion/failure. A completed response does not guarantee AI Influence accepted a new event.
5. Save and reload to check history retention. The session log reports how many reports were restored.

If something is missing, send `bridge.log`, `last-captured-reports.json`, `last-character-context.txt`, and `last-injected-context.txt`. These separate capture from selection and injection. The files contain game reports, including personal ones when enabled; they do not intentionally contain provider credentials or the full AI prompt.

## Settings

Edit `settings.json` while Bannerlord is closed. Existing explicit settings are preserved; missing fields use the defaults below. The file is not rewritten merely to display new fields.

| Setting | Default | Meaning |
|---|---:|---|
| Enabled | true | Master switch |
| ShareAllBellumUpdates | true | Capture all notification flags, enable direct listener, make all retained reports eligible for all characters, and prioritize newest news |
| EnableCharacterKnowledge | true | Supply character dialogue context |
| ShowInjectionMessages | true | Show the two injection blurbs |
| CharacterMaxPromptEvents | 24 | Character report limit |
| CharacterMaxPromptCharacters | 10000 | Character context size limit |
| IncludePublicNotifications | true | Shared public capture when broad sharing is OFF |
| IncludePersonalNotifications | false | Shared player-directed capture when broad sharing is OFF |
| IncludeFactionSnapshot | true | Include current faction snapshots |
| WriteDiagnostics | true | Write logs and diagnostic context/report files |
| RetentionDays | 30 | Campaign days of retained reports |
| MaxStoredEvents | 160 | Saved report count limit |
| MaxPromptEvents | 24 | Dynamic prompt report limit |
| MaxPromptCharacters | 10000 | Dynamic context size limit |
| SnapshotMaxCharacters | 2500 | Dynamic snapshot budget, also bounded by total context |

Setting `ShareAllBellumUpdates` to false restores the older selective behavior: local/clan/hero public reports and major foreign news for characters; player-directed reports excluded from characters; ordinary public/personal capture switches honored; direct notification listener disabled; major reports prioritized for dynamic events.

`Enabled: false` disables all integration on restart. `EnableCharacterKnowledge: false` disables only dialogue augmentation. Neither switch resets NPC memory.

## Source and validation

`Source` contains only this bridge's code, build project and tests. Parent-mod/game DLLs and Harmony are not bundled. With a .NET 8 SDK, run `Source\build.ps1 -GamePath '<Bannerlord root>'` to rebuild. It produces an uninstalled module under `Source\dist\Modules\BellumAIEventBridge`.

Automated tests cover the reported foreign-news case, player-directed updates, old settings defaults, prompt/storage limits, equal-timestamp ordering, retention, save/load, deduplication, notification-origin filtering and legacy selective mode. The existing tests execute Harmony-generated managed wrapper IL for all four character entry points and both dynamic request signatures, including fallback on augmentation errors and preservation of original prompt metadata and tasks.

Native Harmony detours and live game/provider requests cannot be tested in this environment. Use `BELLUM_TEST_MANAGED_WRAPPERS=1` for the managed fixture tests here. See `VALIDATION.txt` for build details. Dialogue on 0.2.1 was reported working by the user; that does not establish live compatibility of every 0.2.2 path.
