using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Threading.Tasks;
using BellumAIEventBridge;
using HarmonyLib;

public sealed class FixtureRequests
{
    public object Received;
    public string Backend;
    public Task<string> Response = Task.FromResult("generated event");
    public int Calls;
    public Task<string> SendAIRequest(FixturePayload payload, string requestType)
    { Received = payload; Calls++; return Response; }
    public Task<string> SendAIRequestWithBackend(FixturePayload payload, string requestType, string backend)
    { Received = payload; Backend = backend; Calls++; return Response; }
    public Task<string> SendAIRequest(FailingPayload payload, string requestType)
    { Received = payload; Calls++; return Response; }
}
public readonly struct FailingPayload
{
    public string FullText { get; }
    public int StaticPrefixLength { get; }
    public FailingPayload(string text, int prefix)
    {
        if (text.Contains(Journal.Marker)) throw new InvalidOperationException("fixture payload construction failed");
        FullText = text; StaticPrefixLength = prefix;
    }
}
internal static class DynamicHookTests
{
    private static void Check(bool value, string reason) { if (!value) throw new Exception(reason); }
    private static MethodInfo Build(MethodInfo original)
    {
        var flags = BindingFlags.Static | BindingFlags.NonPublic;
        var prefix = typeof(DynamicHooks).GetMethod("RequestPrefix", flags).MakeGenericMethod(original.GetParameters()[0].ParameterType);
        var postfix = typeof(DynamicHooks).GetMethod("RequestPostfix", flags);
        var finalizer = typeof(DynamicHooks).GetMethod("RequestFinalizer", flags);
        var patcher = typeof(Harmony).Assembly.GetType("HarmonyLib.MethodPatcher", true);
        var ctor = patcher.GetConstructors(BindingFlags.Instance | BindingFlags.NonPublic | BindingFlags.Public).Single();
        var instance = ctor.Invoke(new object[] { original, null, new List<MethodInfo> { prefix }, new List<MethodInfo> { postfix }, new List<MethodInfo>(), new List<MethodInfo> { finalizer }, false });
        return (MethodInfo)patcher.GetMethod("CreateReplacement", BindingFlags.Instance | BindingFlags.NonPublic | BindingFlags.Public).Invoke(instance, new object[] { null });
    }
    internal static void Run()
    {
        var host = new BridgeBehavior { Context = Journal.Marker + "\nPublic news.\n" };
        BridgeBehavior.Current = host;
        var requests = new FixtureRequests();
        foreach (var name in new[] { "SendAIRequest", "SendAIRequestWithBackend" })
        {
            var types = name == "SendAIRequest" ? new[] { typeof(FixturePayload), typeof(string) } : new[] { typeof(FixturePayload), typeof(string), typeof(string) };
            var wrapper = Build(typeof(FixtureRequests).GetMethod(name, types));
            var original = new FixturePayload("STATIC" + "ORIGINAL DATA AND FINAL INSTRUCTION", 6);
            Func<object, string, object> invoke = (payload, label) => wrapper.Invoke(null, name == "SendAIRequest" ?
                new object[] { requests, payload, label } : new object[] { requests, payload, label, "SelectedBackend" });
            var task = invoke(original, DynamicHooks.GenerationRequest);
            Check(ReferenceEquals(task, requests.Response), "Request task was replaced.");
            var sent = (FixturePayload)requests.Received;
            Check(sent.FullText.StartsWith("STATIC") && sent.FullText.EndsWith("ORIGINAL DATA AND FINAL INSTRUCTION") && sent.StaticPrefixLength == 6 && sent.FullText.Contains(Journal.Marker), "Dynamic context damaged original request.");
            if (name.EndsWith("WithBackend")) Check(requests.Backend == "SelectedBackend", "Backend choice changed.");
            int notices = host.Injections;
            invoke(sent, DynamicHooks.GenerationRequest);
            Check(((FixturePayload)requests.Received).FullText == sent.FullText && host.Injections == notices, "Repeated handoff duplicated context or notice.");
            foreach (var label in new[] { "raw", "unique_role_character_spawn", "dynamic_event_generation_other", "dialogue_analysis", null })
            {
                invoke(original, label);
                Check(((FixturePayload)requests.Received).FullText == original.FullText && host.Injections == notices, "Unrelated request modified: " + label);
            }
            host.Context = ""; invoke(original, DynamicHooks.GenerationRequest);
            Check(((FixturePayload)requests.Received).FullText == original.FullText && host.Injections == notices, "Empty context altered request.");
            host.Context = Journal.Marker + "\nPublic news.\n";
            requests.Response = Task.FromException<string>(new InvalidOperationException("fixture provider fault"));
            Check(ReferenceEquals(invoke(original, DynamicHooks.GenerationRequest), requests.Response), "Provider fault task was replaced.");
            Check(Diagnostics.Messages.Any(m => m.Contains("Dynamic request task failed") && m.Contains("fixture provider fault")), "Async failure not logged.");
            requests.Response = Task.FromResult("generated event");
        }
        var failing = Build(typeof(FixtureRequests).GetMethod("SendAIRequest", new[] { typeof(FailingPayload), typeof(string) }));
        int before = host.Injections, calls = requests.Calls;
        failing.Invoke(null, new object[] { requests, new FailingPayload("original", 0), DynamicHooks.GenerationRequest });
        Check(((FailingPayload)requests.Received).FullText == "original" && requests.Calls == calls + 1 && host.Injections == before, "Augmentation failure must send the original request without a success notice.");
        Check(Diagnostics.Messages.Any(m => m.Contains("fixture payload construction failed")), "Constructor failure not logged.");
        BridgeBehavior.Current = null;
        Console.WriteLine("PASS: Harmony-generated dynamic request prefixes, exact request-type filtering, original prefix/final instructions/backend/task, duplicate guard, constructor-failure fallback and asynchronous failure diagnostics. Native detours NOT tested by this fixture.");
    }
}
