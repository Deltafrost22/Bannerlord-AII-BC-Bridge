// Engine-shaped doubles permit the ACTUAL BridgeBehavior.SyncData implementation
// to run in CI without launching Bannerlord. They do not replace live testing.
using System;
using System.Collections.Generic;
using System.IO;
using System.Reflection;
using BellumAIEventBridge;
using TaleWorlds.CampaignSystem;

namespace TaleWorlds.CampaignSystem
{
    public interface IDataStore
    { bool IsSaving { get; } bool IsLoading { get; } bool SyncData<T>(string key, ref T value); }
    public abstract class CampaignBehaviorBase
    { public abstract void RegisterEvents(); public abstract void SyncData(IDataStore store); }
    public sealed class Hero { }
    public sealed class CampaignGameStarter { }
    public sealed class SessionEvent { public void AddNonSerializedListener(object owner, Action<CampaignGameStarter> callback) { } }
    public static class CampaignEvents { public static SessionEvent OnSessionLaunchedEvent = new SessionEvent(); }
    public sealed class Campaign { public static Campaign Current = new Campaign(); }
    public struct CampaignTime { public static CampaignTime Now; public double ToDays => 52673.822806780096; }
}
namespace TaleWorlds.Library
{
    public sealed class InformationMessage { public InformationMessage(string value) { } }
    public static class InformationManager { public static void DisplayMessage(InformationMessage value) { } }
}
namespace BellumAIEventBridge
{
    internal static class Diagnostics
    {
        public static BridgeSettings Settings = new BridgeSettings();
        public static void Log(string s) { }
        public static void WriteContext(string s) { }
        public static void WriteCharacterContext(string s) { }
        public static void WriteCapturedReports(string s) { }
    }
    internal static class Hooks
    { public static bool SummaryReady = true, PromptReady = true, CharacterReady = true; public static void Install() { } }
    internal static class BellumReader
    {
        public static string Snapshot() => "";
        public static Dictionary<Hero, CharacterAudience> BuildAudiences() => new Dictionary<Hero, CharacterAudience>();
    }
}
static class BehaviorPersistenceTests
{
    sealed class DataStore : IDataStore
    {
        internal PersistenceTests.Store Wire = new PersistenceTests.Store();
        public bool IsSaving { get; set; }
        public bool IsLoading => !IsSaving;
        public bool SyncData<T>(string key, ref T value)
        {
            if (typeof(T) != typeof(string)) throw new Exception("Unexpected persistence type.");
            string text = (string)(object)value;
            bool result = IsSaving ? Wire.Write(key, ref text) : Wire.Read(key, ref text);
            value = (T)(object)text; return result;
        }
    }
    static Journal JournalOf(BridgeBehavior behavior)
    { return (Journal)typeof(BridgeBehavior).GetField("journal", BindingFlags.Instance | BindingFlags.NonPublic).GetValue(behavior); }
    static void Check(bool value, string message) { if (!value) throw new Exception(message); }
    static void Main()
    {
        string full = File.ReadAllText(Path.Combine(AppContext.BaseDirectory, "fixtures/day629-original.json"));
        string repaired = File.ReadAllText(Path.Combine(AppContext.BaseDirectory, "fixtures/day629-repaired.json"));
        var original = new BridgeBehavior(); JournalOf(original).Load(full);
        var saving = new DataStore { IsSaving = true }; original.SyncData(saving);
        var loaded = new BridgeBehavior(); saving.IsSaving = false; loaded.SyncData(saving);
        Check(JournalOf(loaded).Count == 106 && JournalOf(loaded).Save() == JournalOf(original).Save(), "Actual SyncData dropped reports.");
        var old = new DataStore(); old.Wire.Values[JournalPersistence.LegacyKey] = repaired;
        var migration = new BridgeBehavior(); migration.SyncData(old);
        Check(JournalOf(migration).Count == 63, "Repaired save migration failed in behavior.");
        old.IsSaving = true; migration.SyncData(old); old.IsSaving = false;
        var migrated = new BridgeBehavior(); migrated.SyncData(old);
        Check(JournalOf(migrated).Save() == JournalOf(migration).Save(), "Migrated behavior reload differs.");
        var empty = new BridgeBehavior(); empty.SyncData(new DataStore());
        Check(JournalOf(empty).Count == 0, "New campaign inherited reports.");
        saving.Wire.Values.Remove(JournalPersistence.ChunkKey(0));
        var broken = new BridgeBehavior();
        try { broken.SyncData(saving); throw new Exception("Missing chunk was swallowed."); } catch (InvalidDataException) { }
        saving.IsSaving = true; int before = saving.Wire.Writes;
        try { broken.SyncData(saving); throw new Exception("Failed load overwrote history."); } catch (InvalidDataException) { }
        Check(before == saving.Wire.Writes, "Faulted behavior mutated save data.");
        Console.WriteLine("PASS: actual BridgeBehavior.SyncData with engine-shaped store: 106-report save/load, repaired legacy migration, campaign isolation, damaged-data rejection and overwrite prevention.");
    }
}
