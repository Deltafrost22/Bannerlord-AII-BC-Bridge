using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using BellumAIEventBridge;

static class PersistenceTests
{
    static int assertions;
    static void Check(bool ok, string message)
    { assertions++; if (!ok) throw new Exception(message); }
    static void Reject(Action action, string message)
    {
        try { action(); }
        catch (InvalidDataException) { assertions++; return; }
        catch (EncoderFallbackException) { assertions++; return; }
        throw new Exception(message);
    }
    // Emulate the relevant archive wire boundary, not just a JSON round trip.
    internal sealed class Store
    {
        internal Dictionary<string, string> Values = new Dictionary<string, string>();
        internal string FailKey;
        internal int Writes;
        internal bool Write(string key, ref string value)
        {
            Writes++;
            if (key == FailKey) return false;
            byte[] utf8 = new UTF8Encoding(false, true).GetBytes(value);
            Check(utf8.Length <= JournalPersistence.ChunkByteLimit, "Writer sent an unsafe string: " + key);
            using (var stream = new MemoryStream())
            {
                var writer = new BinaryWriter(stream);
                writer.Write(checked((short)(utf8.Length + 4)));
                writer.Write(utf8.Length); writer.Write(utf8); writer.Flush();
                stream.Position = 0;
                var reader = new BinaryReader(stream);
                int entry = reader.ReadInt16(), length = reader.ReadInt32();
                Check(entry == length + 4 && entry >= 0, "Archive length overflowed.");
                Values[key] = Encoding.UTF8.GetString(reader.ReadBytes(length));
                Check(stream.Position == stream.Length, "Archive entry was not fully consumed.");
            }
            return true;
        }
        internal bool Read(string key, ref string value)
        {
            if (!Values.TryGetValue(key, out var found)) return false;
            value = found; return true;
        }
        internal Store Copy() { return new Store { Values = new Dictionary<string, string>(Values) }; }
    }
    static string Fixture(string name)
    { return File.ReadAllText(Path.Combine(AppContext.BaseDirectory, "fixtures", name)); }
    static void RoundTrip(string text)
    {
        var store = new Store(); JournalPersistence.Save(store.Write, text);
        Check(JournalPersistence.Load(store.Read) == text, "Transport altered payload.");
        Check(store.Values[JournalPersistence.LegacyKey] == "", "Oversized legacy dual-write returned.");
    }
    internal static void Run()
    {
        foreach (int n in new[] { 0, 1, 23999, 24000, 24001, 32762, 32763, 32764, 32767, 32768, 38669, 54314, 65536, 2000000 })
            RoundTrip(new string('x', n));
        RoundTrip(new string('界', 100000));
        RoundTrip(new string('é', 30000));
        var unicodeJournal = new Journal(new BridgeSettings());
        unicodeJournal.Add("emoji", 100, "PublicReport", new string('x', 1398) + "😀trailing text", false);
        RoundTrip(unicodeJournal.Save());
        Check(!Journal.Clean(new string('x', 1398) + "😀tail").Contains("\ud83d"), "Report cleaning split a surrogate pair.");
        RoundTrip(new string('x', 23999) + "😀" + string.Concat(Enumerable.Repeat("界😀é\\\"\r\n", 10000)));
        var random = new Random(223);
        for (int i = 0; i < 30; i++)
        {
            var text = new StringBuilder();
            for (int j = 0; j < 20000; j++) text.Append(char.ConvertFromUtf32(random.Next(0x10000, 0x10ffff)));
            RoundTrip(text.ToString());
        }
        var badWrite = new Store();
        Reject(() => JournalPersistence.Save(badWrite.Write, "\ud800"), "Malformed Unicode was silently replaced.");
        Check(badWrite.Writes == 0, "Validation happened after touching store.");
        Reject(() => JournalPersistence.Save(badWrite.Write, new string('x', JournalPersistence.MaxPayloadBytes + 1)), "Oversized aggregate was silently trimmed.");
        Check(badWrite.Writes == 0, "Oversized aggregate partially written.");

        string full = Fixture("day629-original.json"), repaired = Fixture("day629-repaired.json");
        int originalBytes = Encoding.UTF8.GetByteCount(full);
        Check(originalBytes == 38669, "Original failure fixture has drifted.");
        Check(unchecked((short)(originalBytes + 4)) == -26863, "Old failure did not reproduce.");
        RoundTrip(full); RoundTrip(repaired);
        var original = new Journal(new BridgeSettings()); original.Load(full);
        Check(original.Count == 106, "Fixture no longer has 106 reports.");
        var storeFull = new Store(); JournalPersistence.Save(storeFull.Write, original.Save());
        var restored = new Journal(new BridgeSettings()); restored.Load(JournalPersistence.Load(storeFull.Read));
        Check(restored.Count == 106 && restored.Save() == original.Save(), "Journal content/metadata lost.");
        var legacy = new Store(); legacy.Values[JournalPersistence.LegacyKey] = repaired;
        Check(JournalPersistence.Load(legacy.Read) == repaired, "Repaired v1 migration failed.");
        JournalPersistence.Save(legacy.Write, JournalPersistence.Load(legacy.Read));
        Check(JournalPersistence.Load(legacy.Read) == repaired, "Migrated journal changed.");
        var empty = new Store(); Check(JournalPersistence.Load(empty.Read) == "", "New campaign not empty.");
        legacy.Values[JournalPersistence.LegacyKey] = "stale";
        Check(JournalPersistence.Load(legacy.Read) == repaired, "Legacy overrides v2.");

        var large = new Journal(new BridgeSettings { MaxStoredEvents = 500 });
        for (int i = 0; i < 500; i++) large.Add("key-" + i, 100, "PublicReport", i + new string('界', 1380), true);
        var stress = new Store(); JournalPersistence.Save(stress.Write, large.Save());
        restored = new Journal(new BridgeSettings { MaxStoredEvents = 500 });
        restored.Load(JournalPersistence.Load(stress.Read));
        Check(restored.Count == 500 && restored.Save() == large.Save(), "Large history was truncated.");
        JournalPersistence.Save(stress.Write, "[]");
        Check(JournalPersistence.Load(stress.Read) == "[]", "Stale chunks leaked after shrinking.");
        for (int i = 0; i < 5; i++) { JournalPersistence.Save(stress.Write, full); Check(JournalPersistence.Load(stress.Read) == full, "Repeated save failed."); }

        foreach (string invalid in new[] { null, "", "3|1|2|" + new string('0', 64), "2|-1|1|x", "2|999999|1|x", "2|1|999999999|x", "2|0|1|x", new string('x', 129) })
        {
            var broken = legacy.Copy(); broken.Values[JournalPersistence.ManifestKey] = invalid;
            Reject(() => JournalPersistence.Load(broken.Read), "Invalid manifest fell back to legacy.");
        }
        var missing = storeFull.Copy(); missing.Values.Remove(JournalPersistence.ChunkKey(0));
        Reject(() => JournalPersistence.Load(missing.Read), "Missing chunk accepted.");
        var changed = storeFull.Copy(); changed.Values[JournalPersistence.ChunkKey(0)] = "X" + changed.Values[JournalPersistence.ChunkKey(0)].Substring(1);
        Reject(() => JournalPersistence.Load(changed.Read), "Corrupted chunk accepted.");
        var swapped = storeFull.Copy(); var first = swapped.Values[JournalPersistence.ChunkKey(0)];
        swapped.Values[JournalPersistence.ChunkKey(0)] = swapped.Values[JournalPersistence.ChunkKey(1)];
        swapped.Values[JournalPersistence.ChunkKey(1)] = first;
        Reject(() => JournalPersistence.Load(swapped.Read), "Reordered chunks accepted.");
        var oversized = storeFull.Copy(); oversized.Values[JournalPersistence.ChunkKey(0)] = new string('界', 24000);
        Reject(() => JournalPersistence.Load(oversized.Read), "Oversized encoded chunk accepted.");
        var failed = new Store { FailKey = JournalPersistence.ChunkKey(0) };
        Reject(() => JournalPersistence.Save(failed.Write, full), "Store failure ignored.");
        Check(!failed.Values.ContainsKey(JournalPersistence.ManifestKey), "Failed write committed manifest.");
        Console.WriteLine("PASS: journal persistence: " + assertions + " assertions; real 106/63-report fixtures, archive byte boundary, Unicode, large journals, migration, corruption rejection and repeated saves.");
    }
}
