using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Reflection;
using BellumAIEventBridge;
using HarmonyLib;
using TaleWorlds.CampaignSystem;

// Minimal host fixtures exercise the actual shipped CharacterHooks code with
// real Harmony detours. These are not a simulation of Bannerlord's full runtime.
namespace TaleWorlds.CampaignSystem { public sealed class Hero { } }
namespace BellumAIEventBridge
{
    internal static class Diagnostics
    {
        internal static readonly List<string> Messages = new List<string>();
        internal static void Log(string value) { Messages.Add(value); }
    }
    internal sealed class BridgeBehavior
    {
        internal static BridgeBehavior Current;
        internal string Context = CharacterKnowledge.Marker + "\nA public rebellion began.\n";
        internal bool Throw;
        internal int Injections;
        internal void OnInjected(string context) { Injections++; }
        internal string CharacterContext(Hero h, out string name)
        { name = "Fixture"; if (Throw) throw new InvalidOperationException("fixture context failure"); return Context; }
        internal void OnCharacterInjected(string context, string name) { Injections++; }
    }
}
public sealed class FixtureNpcContext { }
public readonly struct FixturePayload
{
    public string FullText { get; }
    public int StaticPrefixLength { get; }
    public FixturePayload(string text, int prefix) { FullText = text; StaticPrefixLength = prefix; }
}
public static class FixtureGenerator
{
    public const string Prefix = "ORIGINAL STATIC PREFIX";
    public const string Tail = "ORIGINAL DIALOGUE AND JSON SCHEMA";
    public static bool Throw;
    [MethodImpl(MethodImplOptions.NoInlining)]
    public static string GeneratePrompt(Hero h, FixtureNpcContext c, bool? a, bool b, Hero p)
    { return GeneratePrompt(h, c, a, b, p, false, out _, false, out _, out _, out _); }
    [MethodImpl(MethodImplOptions.NoInlining)]
    public static string GeneratePrompt(Hero h, FixtureNpcContext c, bool? a, bool b, Hero p, bool omit, out string participant)
    { return GeneratePrompt(h, c, a, b, p, omit, out participant, false, out _, out _, out _); }
    [MethodImpl(MethodImplOptions.NoInlining)]
    public static FixturePayload GeneratePromptPayload(Hero h, FixtureNpcContext c, bool? a, bool b, Hero p)
    { string text = GeneratePrompt(h, c, a, b, p, false, out _, false, out _, out _, out int prefix); return new FixturePayload(text, prefix); }
    [MethodImpl(MethodImplOptions.NoInlining)]
    public static FixturePayload GeneratePromptPayload(Hero h, FixtureNpcContext c, bool? a, bool b, Hero p, bool omit, out string participant, bool defer, out string history, out string tail)
    { string text = GeneratePrompt(h, c, a, b, p, omit, out participant, defer, out history, out tail, out int prefix); return new FixturePayload(text, prefix); }
    [MethodImpl(MethodImplOptions.NoInlining)]
    public static string GeneratePrompt(Hero h, FixtureNpcContext c, bool? a, bool b, Hero p, bool omit, out string participant, bool defer, out string history, out string tail, out int prefix)
    {
        if (Throw) throw new InvalidOperationException("fixture parent failure");
        participant = omit ? "DEFERRED PARTICIPANT" : null;
        history = defer ? "DEFERRED HISTORY" : null;
        tail = defer ? "DEFERRED TAIL" : null;
        prefix = Prefix.Length;
        return Prefix + (defer ? "" : Tail);
    }
}
internal static class HookTests
{
    private static void Check(bool value, string reason) { if (!value) throw new Exception(reason); }
    internal static void Run()
    {
        if (Environment.GetEnvironmentVariable("BELLUM_TEST_MANAGED_WRAPPERS") == "1") { RunManagedWrappers(); return; }
        var harmony = new Harmony("bridge.v021.fixture");
        var host = new BridgeBehavior(); BridgeBehavior.Current = host;
        var hero = new Hero(); var npc = new FixtureNpcContext();
        try
        {
            Check(CharacterHooks.Install(harmony, typeof(FixtureGenerator), typeof(FixtureNpcContext)), "Four wrapper detours must install.");
            Check(CharacterHooks.Install(harmony, typeof(FixtureGenerator), typeof(FixtureNpcContext)), "Installation must be idempotent.");
            var core = typeof(FixtureGenerator).GetMethods().Single(m => m.Name == "GeneratePrompt" && m.GetParameters().Length == 11);
            Check(Harmony.GetPatchInfo(core) == null, "Core prompt builder must stay unpatched.");
            string plain = FixtureGenerator.GeneratePrompt(hero, npc, null, false, null);
            Check(plain.Contains(CharacterKnowledge.Marker) && plain.EndsWith(FixtureGenerator.Prefix + FixtureGenerator.Tail), "String wrapper must preserve original prompt.");
            FixtureGenerator.GeneratePrompt(hero, npc, null, false, null, true, out string participant);
            Check(participant == "DEFERRED PARTICIPANT", "String wrapper lost out participant.");
            var payload = FixtureGenerator.GeneratePromptPayload(hero, npc, null, false, null);
            Check(payload.StaticPrefixLength == FixtureGenerator.Prefix.Length && payload.FullText.StartsWith(FixtureGenerator.Prefix) && payload.FullText.EndsWith(FixtureGenerator.Tail), "Payload prefix or suffix changed.");
            Check(payload.FullText.Contains(CharacterKnowledge.Marker), "Generic struct postfix did not update actual return value.");
            payload = FixtureGenerator.GeneratePromptPayload(hero, npc, null, true, null, true, out participant, true, out string history, out string tail);
            Check(participant == "DEFERRED PARTICIPANT" && history == "DEFERRED HISTORY" && tail == "DEFERRED TAIL", "Extended wrapper lost deferred parts.");
            Check(payload.FullText.Contains(CharacterKnowledge.Marker) && payload.StaticPrefixLength == FixtureGenerator.Prefix.Length, "Deferred payload lost injected text or boundary.");
            Check(host.Injections == 4, "Every wrapper should inject exactly once, without duplicate patches.");

            host.Throw = true;
            payload = FixtureGenerator.GeneratePromptPayload(hero, npc, null, false, null);
            Check(payload.FullText == FixtureGenerator.Prefix + FixtureGenerator.Tail, "Bridge failure corrupted original payload.");
            Check(FixtureGenerator.GeneratePrompt(hero, npc, null, false, null) == FixtureGenerator.Prefix + FixtureGenerator.Tail, "Bridge failure corrupted original string.");
            Check(host.Injections == 4 && Diagnostics.Messages.Any(m => m.Contains("fixture context failure") && m.Contains("CharacterContext")), "Failure must log stack and not display success notice.");
            host.Throw = false; host.Context = "";
            Check(FixtureGenerator.GeneratePromptPayload(hero, npc, null, false, null).FullText == FixtureGenerator.Prefix + FixtureGenerator.Tail, "Empty context altered payload.");
            var adapter = new PromptPayloadAdapter(typeof(FixturePayload));
            var invalid = new FixturePayload("short", 50);
            Check(!adapter.TryAugment(invalid, CharacterKnowledge.Marker, out object unchanged) && ((FixturePayload)unchanged).FullText == "short", "Invalid boundary altered payload.");
            var duplicate = new FixturePayload(CharacterKnowledge.Marker, 0);
            Check(!adapter.TryAugment(duplicate, CharacterKnowledge.Marker, out _), "Duplicate payload injection accepted.");
            FixtureGenerator.Throw = true;
            bool propagated = false;
            try { FixtureGenerator.GeneratePromptPayload(hero, npc, null, false, null); }
            catch (InvalidOperationException e) { propagated = e.Message == "fixture parent failure"; }
            Check(propagated && Diagnostics.Messages.Any(m => m.Contains("Dialogue wrapper failed") && m.Contains("fixture parent failure")), "Parent exception must be logged and retain original behavior.");
            Console.WriteLine("PASS: real Harmony wrapper detours, readonly payload replacement, untouched core, deferred arguments, idempotent install, failure fallback and exception diagnostics.");
        }
        catch { Console.WriteLine(string.Join("\n", Diagnostics.Messages)); throw; }
        finally { harmony.UnpatchAll(harmony.Id); FixtureGenerator.Throw = false; BridgeBehavior.Current = null; }
    }

    private static MethodInfo BuildManagedWrapper(MethodInfo original)
    {
        var flags = BindingFlags.Static | BindingFlags.NonPublic;
        var postfix = typeof(CharacterHooks).GetMethod(original.ReturnType == typeof(string) ? "StringPostfix" : "PayloadPostfix", flags);
        if (postfix.IsGenericMethodDefinition) postfix = postfix.MakeGenericMethod(original.ReturnType);
        var finalizer = typeof(CharacterHooks).GetMethod("WrapperFinalizer", flags);
        var patcherType = typeof(Harmony).Assembly.GetType("HarmonyLib.MethodPatcher", true);
        var ctor = patcherType.GetConstructors(BindingFlags.Instance | BindingFlags.NonPublic | BindingFlags.Public).Single();
        object patcher = ctor.Invoke(new object[] { original, null, new List<MethodInfo>(), new List<MethodInfo> { postfix },
            new List<MethodInfo>(), new List<MethodInfo> { finalizer }, false });
        return (MethodInfo)patcherType.GetMethod("CreateReplacement", BindingFlags.Instance | BindingFlags.NonPublic | BindingFlags.Public)
            .Invoke(patcher, new object[] { null });
    }

    private static void RunManagedWrappers()
    {
        // Execute Harmony's generated replacement IL directly, without installing
        // a native detour. This validates real argument/result binding, including
        // ref readonly-struct results. Native detour installation is NOT tested.
        var host = new BridgeBehavior(); BridgeBehavior.Current = host;
        var hero = new Hero(); var npc = new FixtureNpcContext();
        var wrappers = typeof(FixtureGenerator).GetMethods().Where(m => m.Name.StartsWith("GeneratePrompt") && m.GetParameters().Length != 11).ToArray();
        foreach (var original in wrappers)
        {
            var patched = BuildManagedWrapper(original);
            object[] args = original.GetParameters().Length == 5 ? new object[] { hero, npc, null, false, null } :
                original.GetParameters().Length == 7 ? new object[] { hero, npc, null, false, null, true, null } :
                new object[] { hero, npc, null, true, null, true, null, true, null, null };
            object result = patched.Invoke(null, args);
            string text = result is string s ? s : ((FixturePayload)result).FullText;
            Check(text.Contains(CharacterKnowledge.Marker), "Generated Harmony wrapper failed to inject: " + original);
            if (result is FixturePayload p) Check(p.StaticPrefixLength == FixtureGenerator.Prefix.Length && p.FullText.StartsWith(FixtureGenerator.Prefix), "Readonly payload prefix not preserved.");
            if (args.Length > 5) Check((string)args[6] == "DEFERRED PARTICIPANT", "Deferred participant changed.");
            if (args.Length == 10) Check((string)args[8] == "DEFERRED HISTORY" && (string)args[9] == "DEFERRED TAIL", "Deferred history/tail changed.");
            else Check(text.EndsWith(FixtureGenerator.Prefix + FixtureGenerator.Tail) || text.EndsWith(FixtureGenerator.Tail), "Original content lost.");
            host.Throw = true;
            result = patched.Invoke(null, args);
            text = result is string t ? t : ((FixturePayload)result).FullText;
            Check(text == FixtureGenerator.Prefix + (args.Length == 10 ? "" : FixtureGenerator.Tail), "Bridge failure did not retain original result.");
            host.Throw = false;
            FixtureGenerator.Throw = true;
            bool propagated = false;
            try { patched.Invoke(null, args); }
            catch (TargetInvocationException e) { propagated = e.InnerException?.Message == "fixture parent failure"; }
            finally { FixtureGenerator.Throw = false; }
            Check(propagated, "Parent failure behavior changed.");
        }
        Check(host.Injections == 4, "Expected exactly four successful injections.");
        Check(Diagnostics.Messages.Any(m => m.Contains("fixture context failure") && m.Contains("CharacterContext")), "Bridge stack trace missing.");
        Check(Diagnostics.Messages.Any(m => m.Contains("Dialogue wrapper failed") && m.Contains("fixture parent failure")), "Parent exception diagnostics missing.");
        var adapter = new PromptPayloadAdapter(typeof(FixturePayload));
        Check(!adapter.TryAugment(new FixturePayload("short", 50), CharacterKnowledge.Marker, out _), "Invalid payload boundary accepted.");
        Check(!adapter.TryAugment(new FixturePayload(CharacterKnowledge.Marker, 0), CharacterKnowledge.Marker, out _), "Duplicate injection accepted.");
        Check(!adapter.TryAugment(new FixturePayload("prompt", 0), "", out _), "Empty context accepted.");
        BridgeBehavior.Current = null;
        Console.WriteLine("PASS: Harmony-generated managed wrapper IL for all four entry points; readonly struct return, prefix, deferred outputs, bridge-failure fallback, parent exception diagnostics. Native detours NOT tested in this mode.");
    }
}
