using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Threading;
using System.Threading.Tasks;
using HarmonyLib;

namespace BellumAIEventBridge
{
    internal static class DynamicHooks
    {
        private static readonly HashSet<MethodBase> Installed = new HashSet<MethodBase>();
        internal static void Clear() { Installed.Clear(); }
        internal const string GenerationRequest = "dynamic_event_generation";
        internal static bool Install(Harmony harmony, Type requests, Type payloadType)
        {
            try { new PromptPayloadAdapter(payloadType); }
            catch (Exception e) { Diagnostics.Log("Dynamic payload layout unsupported: " + e); return false; }
            int count = 0;
            foreach (var method in new[] {
                requests.GetMethod("SendAIRequest", new[] { payloadType, typeof(string) }),
                requests.GetMethod("SendAIRequestWithBackend", new[] { payloadType, typeof(string), typeof(string) })
            })
            {
                if (method == null || method.IsStatic || method.ReturnType != typeof(Task<string>)) continue;
                try
                {
                    if (Installed.Contains(method)) { count++; continue; }
                    var flags = BindingFlags.Static | BindingFlags.NonPublic;
                    harmony.Patch(method,
                        prefix: new HarmonyMethod(typeof(DynamicHooks).GetMethod(nameof(RequestPrefix), flags).MakeGenericMethod(payloadType)),
                        postfix: new HarmonyMethod(typeof(DynamicHooks).GetMethod(nameof(RequestPostfix), flags)),
                        finalizer: new HarmonyMethod(typeof(DynamicHooks).GetMethod(nameof(RequestFinalizer), flags)));
                    Diagnostics.Log("Dynamic request hook installed: " + method.Name);
                    Installed.Add(method);
                    count++;
                }
                catch (Exception e) { Diagnostics.Log("Dynamic request hook installation failed: " + method.Name + ": " + e); }
            }
            Diagnostics.Log("Dynamic request hooks available=" + count + "/2; BuildFinalInstruction left unpatched by bridge.");
            return count == 2;
        }

        private static void RequestPrefix<T>(ref T __0, string __1, out bool __state)
        {
            __state = string.Equals(__1, GenerationRequest, StringComparison.Ordinal);
            if (!__state) return;
            T original = __0;
            try
            {
                Diagnostics.Log("Completed dynamic-event prompt reached request handoff.");
                var behavior = BridgeBehavior.Current;
                string context = behavior?.Context;
                if (string.IsNullOrWhiteSpace(context))
                { Diagnostics.Log("Dynamic request unchanged: no Bellum context available."); return; }
                object candidate;
                if (!PayloadAccess<T>.Adapter.TryAugment(__0, context, out candidate, dynamicEvents: true))
                { Diagnostics.Log("Dynamic request unchanged: duplicate marker, empty prompt, or invalid cache boundary."); return; }
                __0 = (T)candidate;
                behavior.OnInjected(context);
            }
            catch (Exception e) { __0 = original; Diagnostics.Log("Dynamic augmentation failed; original payload restored: " + e); }
            // Void prefix: ALWAYS run the original request method.
        }

        private static class PayloadAccess<T>
        {
            internal static readonly PromptPayloadAdapter Adapter = new PromptPayloadAdapter(typeof(T));
        }

        private static void RequestPostfix(Task<string> __result, bool __state)
        {
            if (!__state) return;
            try
            {
                if (__result == null) { Diagnostics.Log("Dynamic request returned no task."); return; }
                // Observe completion without replacing/awaiting/retrying the task.
                __result.ContinueWith(t => {
                    if (t.IsFaulted) Diagnostics.Log("Dynamic request task failed: " + t.Exception);
                    else if (t.IsCanceled) Diagnostics.Log("Dynamic request task canceled.");
                    else Diagnostics.Log("Dynamic request completed; response characters=" + (t.Result?.Length ?? 0));
                }, CancellationToken.None, TaskContinuationOptions.ExecuteSynchronously, TaskScheduler.Default);
            }
            catch (Exception e) { Diagnostics.Log("Dynamic completion observer failed: " + e); }
        }

        private static Exception RequestFinalizer(Exception __exception, bool __state)
        {
            if (__state && __exception != null) Diagnostics.Log("Dynamic request handoff failed: " + __exception);
            return __exception;
        }
    }
}
