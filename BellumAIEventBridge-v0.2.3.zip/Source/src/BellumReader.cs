using System;
using System.Collections;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Reflection;
using System.Text;
using TaleWorlds.CampaignSystem;

namespace BellumAIEventBridge
{
    internal static class BellumReader
    {
        private const BindingFlags Flags = BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance;
        public static object Get(object instance, string member)
        {
            if (instance == null) return null;
            var t = instance.GetType();
            var p = t.GetProperty(member, Flags);
            return p != null ? p.GetValue(instance, null) : t.GetField(member, Flags)?.GetValue(instance);
        }
        public static bool Flag(object instance, string member) { return Get(instance, member) is bool b && b; }
        public static string KingdomLabel(Kingdom k)
        { return k == null ? "unknown realm" : Journal.Clean(k.Name?.ToString(), 120) + " (kingdom_id=" + k.StringId + ")"; }
        public static string ClanLabel(Clan c)
        { return c == null ? "unknown clan" : Journal.Clean(c.Name?.ToString(), 100) + " (clan_id=" + c.StringId + ")"; }
        public static string HeroLabel(Hero h)
        { return h == null ? "unknown leader" : Journal.Clean(h.Name?.ToString(), 100) + " (hero_id=" + h.StringId + ")"; }
        public static string FactionName(object faction)
        {
            return Journal.Clean(faction.GetType().GetMethod("GetDisplayName", Type.EmptyTypes)?.Invoke(faction, null)?.ToString()
                ?? Get(faction, "Name")?.ToString(), 160);
        }
        public static string FactionKey(object faction)
        {
            var created = Get(faction, "CreationDate");
            var days = created is CampaignTime t ? t.ToDays.ToString("R", CultureInfo.InvariantCulture) : "unknown";
            return (Get(faction, "ParentKingdom") as Kingdom)?.StringId + "/" + Get(faction, "Type") + "/" + days + "/" + Get(faction, "Name");
        }
        public static string DescribeFaction(object faction)
        {
            var parent = Get(faction, "ParentKingdom") as Kingdom;
            var leader = Get(faction, "Leader") as Clan;
            var sb = new StringBuilder();
            sb.Append(Flag(faction, "IsGrandCoalition") ? "Grand coalition " : "Faction ");
            sb.Append(FactionName(faction)).Append("; cause=").Append(Get(faction, "Type"));
            sb.Append("; parent=").Append(KingdomLabel(parent));
            sb.Append("; leading clan=").Append(ClanLabel(leader));
            sb.Append("; leader=").Append(HeroLabel(leader?.Leader));
            var members = (Get(faction, "Members") as IEnumerable)?.Cast<object>().OfType<Clan>().ToList();
            if (members != null)
                sb.Append("; supporting clans=").Append(string.Join(", ", members.Take(6).Select(ClanLabel)))
                  .Append(members.Count > 6 ? " (+" + (members.Count - 6) + " more)" : "");
            return sb.ToString();
        }
        public static string SummaryReport(string method, object faction, object second)
        {
            string action;
            switch (method)
            {
                case "RecordFactionFormed": action = "Bellum recorded formation of this rebel faction. "; break;
                case "RecordUltimatumIssued": action = "Bellum recorded an ultimatum from this faction; acceptance or refusal is not established by this report. "; break;
                case "RecordCivilWarStarted": action = "Bellum recorded a civil war starting; rebel realm=" + KingdomLabel(second as Kingdom) + ". "; break;
                case "RecordOutcome":
                    var outcome = second?.ToString() ?? "Unknown";
                    var outcomes = new Dictionary<string, string> {
                        { "LoyalistVictory", "loyalist victory" }, { "RebelVictory", "rebel victory" },
                        { "WhitePeace", "white peace" }, { "RecognizedIndependence", "recognized independence" },
                        { "AcceptedUltimatum", "accepted ultimatum" }
                    };
                    action = "Bellum recorded outcome: " + (outcomes.TryGetValue(outcome, out var result) ? result : outcome) +
                        ". This report alone does not establish the final land transfers or ruler appointments. "; break;
                default: return "";
            }
            return action + DescribeFaction(faction);
        }

        // Called only on the campaign thread. Read tracked fields directly to avoid
        // Bellum's GetRebelKingdom fallback, which may update Bellum's cached state.
        public static string Snapshot()
        {
            var assembly = AppDomain.CurrentDomain.GetAssemblies().FirstOrDefault(a => a.GetName().Name == "BellumCivile");
            var type = assembly?.GetType("BellumCivile.Behaviors.FactionManagerBehavior");
            if (type == null || Campaign.Current == null) return "";
            var getter = typeof(Campaign).GetMethods().First(m => m.Name == "GetCampaignBehavior" && m.IsGenericMethodDefinition && m.GetParameters().Length == 0);
            var behavior = getter.MakeGenericMethod(type).Invoke(Campaign.Current, null);
            var factions = (Get(behavior, "_activeFactions") as IEnumerable)?.Cast<object>().Where(f => f != null && !Flag(f, "IsIdeology")).ToList();
            if (factions == null) return "";
            var lines = new List<Tuple<bool, string>>();
            foreach (var faction in factions)
            {
                var parent = Get(faction, "ParentKingdom") as Kingdom;
                if (parent == null || parent.IsEliminated) continue;
                var rebel = Get(faction, "_rebelKingdom") as Kingdom;
                string id = Get(faction, "_rebelKingdomStringId") as string;
                if ((rebel == null || rebel.IsEliminated) && !string.IsNullOrEmpty(id))
                    rebel = Kingdom.All.FirstOrDefault(k => k.StringId == id && !k.IsEliminated);
                bool war = rebel != null && !rebel.IsEliminated && rebel.IsAtWarWith(parent);
                string state = war ? "Active civil war; rebel realm=" + KingdomLabel(rebel) :
                    Flag(faction, "IsUltimatumPending") ? "Ultimatum pending" : "Organized faction; no active civil war confirmed";
                lines.Add(Tuple.Create(war, Journal.Clean(state + ". " + DescribeFaction(faction), 1000)));
            }
            return string.Join("\n", lines.OrderByDescending(x => x.Item1).Select(x => "- " + x.Item2));
        }

        public static Dictionary<Hero, CharacterAudience> BuildAudiences()
        {
            var assembly = AppDomain.CurrentDomain.GetAssemblies().FirstOrDefault(a => a.GetName().Name == "BellumCivile");
            var type = assembly?.GetType("BellumCivile.Behaviors.FactionManagerBehavior");
            if (type == null || Campaign.Current == null) return new Dictionary<Hero, CharacterAudience>();
            var getter = typeof(Campaign).GetMethods().First(m => m.Name == "GetCampaignBehavior" && m.IsGenericMethodDefinition && m.GetParameters().Length == 0);
            var manager = getter.MakeGenericMethod(type).Invoke(Campaign.Current, null);
            var factions = (Get(manager, "_activeFactions") as IEnumerable)?.Cast<object>().Where(f => f != null).ToList() ?? new List<object>();
            var ownFacts = new Dictionary<Clan, List<string>>();
            var localFacts = new Dictionary<Kingdom, List<string>>();
            var clanRealms = new Dictionary<Clan, HashSet<string>>();
            foreach (var f in factions)
            {
                var parent = Get(f, "ParentKingdom") as Kingdom;
                if (parent == null || parent.IsEliminated) continue;
                var leader = Get(f, "Leader") as Clan;
                bool ideology = Flag(f, "IsIdeology");
                string fact = FactionName(f) + " (" + Get(f, "Type") + ") in " + KingdomLabel(parent) +
                    "; leading clan: " + ClanLabel(leader) + "; leader: " + HeroLabel(leader?.Leader) + ".";
                if (!ideology)
                {
                    var rebel = Get(f, "_rebelKingdom") as Kingdom;
                    string rebelId = Get(f, "_rebelKingdomStringId") as string;
                    if ((rebel == null || rebel.IsEliminated) && !string.IsNullOrEmpty(rebelId))
                        rebel = Kingdom.All.FirstOrDefault(k => k.StringId == rebelId && !k.IsEliminated);
                    if (rebel != null && !rebel.IsEliminated && rebel.IsAtWarWith(parent))
                        fact += " Active civil war; rebel realm: " + KingdomLabel(rebel) + ".";
                    else if (Flag(f, "IsUltimatumPending")) fact += " An ultimatum is pending.";
                    else fact += " Organized faction; no active civil war confirmed by this snapshot.";
                    if (!localFacts.ContainsKey(parent)) localFacts[parent] = new List<string>();
                    localFacts[parent].Add(fact);
                }
                var members = (Get(f, "Members") as IEnumerable)?.Cast<object>().OfType<Clan>() ?? Enumerable.Empty<Clan>();
                foreach (var clan in members.Concat(new[] { leader }).Where(c => c != null).Distinct())
                {
                    if (!ownFacts.ContainsKey(clan)) { ownFacts[clan] = new List<string>(); clanRealms[clan] = new HashSet<string>(); }
                    ownFacts[clan].Add("Your clan " + ClanLabel(clan) + (clan == leader ? " leads " : " belongs to ") + fact);
                    clanRealms[clan].Add(parent.StringId);
                }
            }
            var result = new Dictionary<Hero, CharacterAudience>();
            foreach (var hero in Hero.AllAliveHeroes)
            {
                if (hero == null || hero == Hero.MainHero) continue;
                var clan = hero.Clan;
                var kingdom = clan?.Kingdom ?? (hero.HomeSettlement ?? hero.CurrentSettlement)?.OwnerClan?.Kingdom;
                result[hero] = new CharacterAudience {
                    HeroId = hero.StringId, Name = Journal.Clean(hero.Name?.ToString(), 120),
                    ClanId = clan?.StringId, KingdomId = kingdom?.StringId,
                    RelevantKingdomIds = clan != null && clanRealms.TryGetValue(clan, out var realms) ? realms.ToArray() : new string[0],
                    OwnFactionFacts = clan != null && ownFacts.TryGetValue(clan, out var own) ? string.Join("\n", own) : "",
                    LocalFactionFacts = kingdom != null && localFacts.TryGetValue(kingdom, out var local) ? string.Join("\n", local) : ""
                };
            }
            return result;
        }
    }
}
