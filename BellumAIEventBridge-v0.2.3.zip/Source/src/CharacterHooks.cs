using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using HarmonyLib;
using TaleWorlds.CampaignSystem;

namespace BellumAIEventBridge
{
    internal static class CharacterHooks
    {
        private static readonly HashSet<MethodBase> Installed = new HashSet<MethodBase>();
        internal static void Clear() { Installed.Clear(); }
        // Do not patch the obfuscated 11-argument GeneratePrompt implementation.
        // These small public wrappers call that original implementation and only
        // receive our context AFTER it has completed. Payload is a readonly struct.
        internal static bool Install(Harmony harmony, Type generator, Type npcContext)
        {
            var basic = new[] { typeof(Hero), npcContext, typeof(bool?), typeof(bool), typeof(Hero) };
            var strings = basic.Concat(new[] { typeof(bool), typeof(string).MakeByRefType() }).ToArray();
            var extended = strings.Concat(new[] { typeof(bool), typeof(string).MakeByRefType(), typeof(string).MakeByRefType() }).ToArray();
            var methods = new[] {
                generator.GetMethod("GeneratePrompt", basic),
                generator.GetMethod("GeneratePrompt", strings),
                generator.GetMethod("GeneratePromptPayload", basic),
                generator.GetMethod("GeneratePromptPayload", extended)
            };
            int count = 0;
            foreach (var method in methods)
            {
                if (method == null || !method.IsStatic) continue;
                try
                {
                    bool isString = method.ReturnType == typeof(string);
                    if (!isString) new PromptPayloadAdapter(method.ReturnType); // Validate before patching.
                    if (Installed.Contains(method)) { count++; continue; }
                    var postfix = typeof(CharacterHooks).GetMethod(isString ? nameof(StringPostfix) : nameof(PayloadPostfix), BindingFlags.NonPublic | BindingFlags.Static);
                    if (!isString) postfix = postfix.MakeGenericMethod(method.ReturnType);
                    harmony.Patch(method, postfix: new HarmonyMethod(postfix),
                        finalizer: new HarmonyMethod(typeof(CharacterHooks).GetMethod(nameof(WrapperFinalizer), BindingFlags.NonPublic | BindingFlags.Static)));
                    Diagnostics.Log("Character wrapper installed: " + method.Name + "/" + method.GetParameters().Length);
                    Installed.Add(method);
                    count++;
                }
                catch (Exception e) { Diagnostics.Log("Character wrapper installation failed: " + method.Name + ": " + e); }
            }
            Diagnostics.Log("Character wrappers available=" + count + "/4; core GeneratePrompt left unpatched by bridge.");
            return count == 4;
        }

        private static void StringPostfix(Hero __0, ref string __result)
        {
            string original = __result;
            try
            {
                var behavior = BridgeBehavior.Current;
                if (behavior == null) return;
                string name;
                string context = behavior.CharacterContext(__0, out name);
                // String-only entry points carry no cache split. Payload entry
                // points below preserve the original split explicitly.
                string candidate = __result;
                if (!PromptAugmentation.TryInsertCharacterContext(ref candidate, 0, context))
                { Diagnostics.Log("Character string wrapper completed; no new applicable context inserted."); return; }
                __result = candidate;
                behavior.OnCharacterInjected(context, name);
            }
            catch (Exception e) { __result = original; Diagnostics.Log("Character string augmentation failed; original prompt restored: " + e); }
        }

        private static void PayloadPostfix<T>(Hero __0, ref T __result)
        {
            T original = __result;
            try
            {
                var behavior = BridgeBehavior.Current;
                if (behavior == null) return;
                string name;
                string context = behavior.CharacterContext(__0, out name);
                if (string.IsNullOrWhiteSpace(context))
                { Diagnostics.Log("Character payload wrapper completed; no applicable Bellum context available."); return; }
                var adapter = PayloadAccess<T>.Adapter;
                object candidate;
                if (!adapter.TryAugment(__result, context, out candidate))
                { Diagnostics.Log("Character payload unchanged: duplicate marker, empty prompt, or invalid cache boundary."); return; }
                // Construct and validate a NEW struct before touching the result.
                // Never mutate readonly fields or use ref object for a value type.
                __result = (T)candidate;
                behavior.OnCharacterInjected(context, name);
            }
            catch (Exception e) { __result = original; Diagnostics.Log("Character payload augmentation failed; original payload restored: " + e); }
        }

        private static class PayloadAccess<T>
        {
            internal static readonly PromptPayloadAdapter Adapter = new PromptPayloadAdapter(typeof(T));
        }

        private static Exception WrapperFinalizer(Exception __exception, MethodBase __originalMethod)
        {
            // Preserve existing AI Influence error handling; don't swallow a
            // parent-mod failure, retry requests, or fabricate an empty response.
            if (__exception != null) Diagnostics.Log("Dialogue wrapper failed before returning: " + __originalMethod.Name + ": " + __exception);
            return __exception;
        }
    }
}
