using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Reflection;
using HarmonyLib;
using TaleWorlds.CampaignSystem;
using TaleWorlds.Library;

namespace BellumAIEventBridge
{
    internal static class Hooks
    {
        private const string Id = "local.bellum.ai.eventbridge.v1";
        private static readonly Harmony Harmony = new Harmony(Id);
        private static readonly HashSet<MethodBase> Patched = new HashSet<MethodBase>();
        internal static bool PromptReady;
        internal static bool SummaryReady;
        internal static bool CharacterReady;
        private static Type FindType(string assembly, string type)
        { return AppDomain.CurrentDomain.GetAssemblies().FirstOrDefault(a => a.GetName().Name == assembly)?.GetType(type); }
        internal static void Install()
        {
            if (!Diagnostics.Settings.Enabled) return;
            try
            {
                var requests = FindType("AIInfluence", "AIInfluence.AIInfluenceBehavior");
                var payload = FindType("AIInfluence", "AIInfluence.API.PromptPayload");
                PromptReady = requests != null && payload != null && DynamicHooks.Install(Harmony, requests, payload);
                var generator = FindType("AIInfluence", "AIInfluence.PromptGenerator");
                var npcContext = FindType("AIInfluence", "AIInfluence.NPCContext");
                if (generator != null && npcContext != null && Diagnostics.Settings.EnableCharacterKnowledge)
                {
                    CharacterReady = CharacterHooks.Install(Harmony, generator, npcContext);
                }
                var summary = FindType("BellumCivile", "BellumCivile.Behaviors.RebellionSummaryBehavior");
                var faction = FindType("BellumCivile", "BellumCivile.FactionObject");
                var outcome = FindType("BellumCivile", "BellumCivile.Behaviors.RebellionSummaryOutcome");
                int count = 0;
                if (summary != null && faction != null && outcome != null)
                {
                    foreach (var name in new[] { "RecordFactionFormed", "RecordUltimatumIssued", "RecordCivilWarStarted", "RecordOutcome" })
                    {
                        Type[] args = name == "RecordCivilWarStarted" ? new[] { faction, typeof(Kingdom) } :
                            name == "RecordOutcome" ? new[] { faction, outcome } : new[] { faction };
                        var method = summary.GetMethod(name, args);
                        if (method != null && method.ReturnType == typeof(void) && Patch(method, nameof(SummaryPostfix))) count++;
                    }
                }
                SummaryReady = count == 4;
                bool noticesReady = false;
                var notices = FindType("BellumCivile", "BellumCivile.BellumCivileNotifications");
                if (notices != null)
                {
                    var method = notices.GetMethod("Show", BindingFlags.Public | BindingFlags.Static, null,
                        new[] { typeof(string), typeof(TaleWorlds.Library.Color), typeof(Kingdom), typeof(Kingdom), typeof(Clan), typeof(Clan), typeof(bool), typeof(bool) }, null);
                    if (method != null) noticesReady = Patch(method, nameof(NotificationPostfix));
                }
                // The game's existing notification event avoids a new global detour.
                InformationManager.DisplayMessageInternal -= DirectNotification;
                if (notices != null && Diagnostics.Settings.ShareAllBellumUpdates)
                    InformationManager.DisplayMessageInternal += DirectNotification;
                Diagnostics.Log("Hooks: dynamic-event prompt=" + PromptReady + "; character prompt=" + CharacterReady + "; rebellion reports=" + count + "/4; public notifications=" + noticesReady +
                    "; direct notification listener=" + (notices != null && Diagnostics.Settings.ShareAllBellumUpdates) +
                    "; ShareAllBellumUpdates=" + Diagnostics.Settings.ShareAllBellumUpdates);
            }
            catch (Exception e) { Diagnostics.Log("Hook installation error: " + e); }
        }
        private static bool Patch(MethodInfo target, string postfixName)
        {
            if (Patched.Contains(target)) return true;
            try
            {
                Harmony.Patch(target, postfix: new HarmonyMethod(typeof(Hooks).GetMethod(postfixName, BindingFlags.Static | BindingFlags.NonPublic)));
                Patched.Add(target);
                return true;
            }
            catch (Exception e) { Diagnostics.Log("Could not patch " + target.Name + ": " + e.GetType().Name + " " + e.Message); return false; }
        }
        internal static void Remove()
        {
            try { Harmony.UnpatchAll(Id); } catch { }
            InformationManager.DisplayMessageInternal -= DirectNotification;
            Patched.Clear(); PromptReady = false; SummaryReady = false; CharacterReady = false;
            CharacterHooks.Clear(); DynamicHooks.Clear();
        }
        private static void SummaryPostfix(MethodBase __originalMethod, object[] __args)
        {
            try
            {
                var faction = __args.Length > 0 ? __args[0] : null;
                if (faction == null || BellumReader.Flag(faction, "IsIdeology") || BellumReader.Get(faction, "ParentKingdom") == null) return;
                object second = __args.Length > 1 ? __args[1] : null;
                string key = "summary/" + __originalMethod.Name + "/" + BellumReader.FactionKey(faction) + "/" +
                    (second is Kingdom k ? k.StringId : second?.ToString());
                BridgeBehavior.Current?.Record(key, __originalMethod.Name.Substring(6), BellumReader.SummaryReport(__originalMethod.Name, faction, second), true);
            }
            catch (Exception e) { Diagnostics.Log("Bellum summary capture skipped: " + e.GetType().Name); }
        }
        private static void NotificationPostfix(object[] __args)
        {
            try
            {
                var settings = Diagnostics.Settings;
                bool personal = (bool)__args[6];
                if (!settings.CaptureNotification(personal)) return;
                string text = __args[0] as string;
                if (string.IsNullOrWhiteSpace(text) || Campaign.Current == null) return;
                var participants = new List<string>();
                foreach (var k in __args.Skip(2).Take(2).OfType<Kingdom>().Distinct()) participants.Add(BellumReader.KingdomLabel(k));
                foreach (var c in __args.Skip(4).Take(2).OfType<Clan>().Distinct()) participants.Add(BellumReader.ClanLabel(c));
                string report = Journal.Clean(text, 1000) + (participants.Count == 0 ? "" : " Participants: " + string.Join("; ", participants));
                string key = "notice/" + Math.Floor(CampaignTime.Now.ToDays).ToString(CultureInfo.InvariantCulture) + "/" + BridgeBehavior.Hash(report);
                BridgeBehavior.Current?.Record(key, personal ? "PersonalReport" : "PublicReport", report, (bool)__args[7]);
            }
            catch (Exception e) { Diagnostics.Log("Bellum notification capture skipped: " + e); }
        }
        private static void DirectNotification(InformationMessage message)
        {
            try
            {
                if (!Diagnostics.Settings.Enabled || !Diagnostics.Settings.ShareAllBellumUpdates ||
                    BridgeBehavior.Current == null || string.IsNullOrWhiteSpace(message?.Information)) return;
                var frames = new System.Diagnostics.StackTrace(false).GetFrames();
                if (frames == null || !NotificationOrigin.IsDirectBellum(frames.Select(f => f.GetMethod()))) return;
                // Publish on the campaign/application thread, not inside UI dispatch.
                BridgeBehavior.Current.QueueDirectNotification(Journal.Clean(message.Information));
            }
            catch (Exception e) { Diagnostics.Log("Direct Bellum notification capture skipped: " + e); }
        }
    }
}
