using System;
using System.Reflection;

namespace BellumAIEventBridge
{
    internal sealed class PromptPayloadAdapter
    {
        private readonly Type type;
        private readonly PropertyInfo text;
        private readonly PropertyInfo prefix;
        private readonly ConstructorInfo constructor;
        internal PromptPayloadAdapter(Type type)
        {
            this.type = type;
            text = type.GetProperty("FullText", BindingFlags.Public | BindingFlags.Instance);
            prefix = type.GetProperty("StaticPrefixLength", BindingFlags.Public | BindingFlags.Instance);
            constructor = type.GetConstructor(new[] { typeof(string), typeof(int) });
            if (!type.IsValueType || text?.PropertyType != typeof(string) || prefix?.PropertyType != typeof(int) ||
                text.GetGetMethod() == null || prefix.GetGetMethod() == null || constructor == null)
                throw new NotSupportedException("Unsupported prompt payload layout: " + type.FullName);
        }
        internal bool TryAugment(object original, string context, out object replacement, bool dynamicEvents = false)
        {
            replacement = original;
            if (original == null || original.GetType() != type) return false;
            string updated = (string)text.GetValue(original);
            int boundary = (int)prefix.GetValue(original);
            bool inserted = dynamicEvents ? PromptAugmentation.TryInsertDynamicContext(ref updated, boundary, context) :
                PromptAugmentation.TryInsertCharacterContext(ref updated, boundary, context);
            if (!inserted) return false;
            object candidate = constructor.Invoke(new object[] { updated, boundary });
            if (!string.Equals((string)text.GetValue(candidate), updated, StringComparison.Ordinal) ||
                (int)prefix.GetValue(candidate) != boundary)
                throw new InvalidOperationException("Prompt payload constructor did not preserve text/cache boundary.");
            replacement = candidate;
            return true;
        }
    }
}
