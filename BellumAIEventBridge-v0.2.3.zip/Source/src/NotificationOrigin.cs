using System.Collections.Generic;
using System.Reflection;

namespace BellumAIEventBridge
{
    internal static class NotificationOrigin
    {
        // Require a real Bellum assembly frame, not matching words in a message.
        // Shared notifications are already captured with richer participant data.
        internal static bool IsDirectBellum(IEnumerable<MethodBase> frames)
        {
            bool bellum = false;
            foreach (var method in frames)
            {
                var type = method?.DeclaringType;
                if (type?.Assembly.GetName().Name != "BellumCivile") continue;
                if (type.FullName == "BellumCivile.BellumCivileNotifications") return false;
                bellum = true;
            }
            return bellum;
        }
    }
}
