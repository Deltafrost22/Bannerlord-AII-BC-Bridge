using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Security.Cryptography;
using System.Text;

namespace BellumAIEventBridge
{
    // Only primitive strings cross IDataStore. No custom saveable types or sidecars.
    internal delegate bool SyncJournalString(string key, ref string value);

    internal static class JournalPersistence
    {
        internal const string LegacyKey = "BellumAIEventBridge_Reports_v1";
        internal const string ManifestKey = "BellumAIEventBridge_Reports_v2";
        internal const int ChunkByteLimit = 24000;
        // Defensive read/allocation limit, not a pruning policy. Oversize writes fail
        // before any SyncData call, rather than silently discarding reports.
        internal const int MaxPayloadBytes = 64 * 1024 * 1024;
        internal const int MaxChunks = (MaxPayloadBytes + ChunkByteLimit - 4) / (ChunkByteLimit - 3);
        private static readonly Encoding Utf8 = new UTF8Encoding(false, true);

        internal static string ChunkKey(int index)
        { return ManifestKey + "_Chunk_" + index.ToString(CultureInfo.InvariantCulture); }

        internal static List<string> Split(string json)
        {
            if (json == null) throw new ArgumentNullException(nameof(json));
            if (Utf8.GetByteCount(json) > MaxPayloadBytes)
                throw new InvalidDataException("Bridge history exceeds the supported persistence budget; no reports were discarded.");
            var chunks = new List<string>();
            int start = 0, bytes = 0;
            for (int i = 0; i < json.Length;)
            {
                char c = json[i];
                int width = char.IsHighSurrogate(c) ? 2 : 1;
                // Strict GetByteCount above has already rejected unpaired surrogates.
                int size = width == 2 ? 4 : c < 0x80 ? 1 : c < 0x800 ? 2 : 3;
                if (bytes + size > ChunkByteLimit)
                {
                    chunks.Add(json.Substring(start, i - start));
                    start = i; bytes = 0;
                }
                bytes += size; i += width;
            }
            if (start < json.Length) chunks.Add(json.Substring(start));
            return chunks;
        }

        private static string Digest(string json)
        {
            using (var hash = SHA256.Create())
                return BitConverter.ToString(hash.ComputeHash(Utf8.GetBytes(json))).Replace("-", "");
        }

        internal static void Save(SyncJournalString sync, string json)
        {
            // Finish serialization, strict Unicode validation and splitting before
            // touching the store. Never emit the complete journal under the v1 key.
            var chunks = Split(json);
            string manifest = "2|" + chunks.Count.ToString(CultureInfo.InvariantCulture) + "|" +
                Utf8.GetByteCount(json).ToString(CultureInfo.InvariantCulture) + "|" + Digest(json);
            for (int i = 0; i < chunks.Count; i++)
            {
                string chunk = chunks[i];
                Write(sync, ChunkKey(i), ref chunk);
            }
            Write(sync, ManifestKey, ref manifest);
            // Explicitly retire old data even if the game reuses a loaded store.
            // Older bridge versions will not recover v2 history on downgrade.
            string retired = "";
            Write(sync, LegacyKey, ref retired);
        }

        private static void Write(SyncJournalString sync, string key, ref string value)
        {
            if (Utf8.GetByteCount(value) > ChunkByteLimit)
                throw new InvalidDataException("Unsafe bridge save entry: " + key);
            if (!sync(key, ref value))
                throw new InvalidDataException("Bridge save entry was not accepted: " + key);
        }

        internal static string Load(SyncJournalString sync)
        {
            string manifest = null;
            if (!sync(ManifestKey, ref manifest))
            {
                string legacy = null;
                return sync(LegacyKey, ref legacy) ? legacy ?? "" : "";
            }
            // Present-but-invalid v2 data must never fall back to stale v1 data.
            if (manifest == null || manifest.Length > 128)
                throw new InvalidDataException("Invalid bridge history manifest.");
            var fields = manifest.Split('|');
            int count, total;
            if (fields.Length != 4 || fields[0] != "2" ||
                !int.TryParse(fields[1], NumberStyles.None, CultureInfo.InvariantCulture, out count) ||
                !int.TryParse(fields[2], NumberStyles.None, CultureInfo.InvariantCulture, out total) ||
                count < 0 || count > MaxChunks || total < 0 || total > MaxPayloadBytes ||
                (count == 0) != (total == 0) || count > total ||
                (long)count * ChunkByteLimit < total || fields[3].Length != 64)
                throw new InvalidDataException("Unsupported or damaged bridge history manifest.");
            var joined = new StringBuilder();
            long bytes = 0;
            for (int i = 0; i < count; i++)
            {
                string chunk = null;
                if (!sync(ChunkKey(i), ref chunk) || string.IsNullOrEmpty(chunk))
                    throw new InvalidDataException("Missing bridge history chunk " + i + ".");
                int size = Utf8.GetByteCount(chunk);
                bytes += size;
                if (size > ChunkByteLimit || bytes > total)
                    throw new InvalidDataException("Invalid bridge history chunk size.");
                joined.Append(chunk);
            }
            string json = joined.ToString();
            if (bytes != total || !string.Equals(Digest(json), fields[3], StringComparison.Ordinal))
                throw new InvalidDataException("Bridge history integrity check failed.");
            return json;
        }
    }
}
