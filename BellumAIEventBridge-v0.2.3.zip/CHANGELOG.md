# 0.2.3

Based only on 0.2.2; no 0.3.x changes included.

- Replace one oversized saved journal string with UTF-8-bounded 24,000-byte chunks.
- Add version/count/byte-length/SHA-256 metadata and strict reload validation.
- Read working/repaired v1 history and migrate on the next save; retire the old field.
- Reject malformed history rather than silently clearing it; prevent saves after a failed history load.
- Preserve existing report count/age retention, sharing, character knowledge and dynamic-event integration.
- Preserve Unicode pairs when report text is truncated.
- Add real campaign fixtures, archive-size regression tests and actual SyncData integration tests with engine-shaped doubles.

Compatibility: old working saves load into 0.2.3. Old bridge versions cannot read v2 history. Already unreadable saves still need repair. No sidecar or new dependency is required.
